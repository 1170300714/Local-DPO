from typing import Optional

from .abc import AbstractDatasetReader
from .. import Features, NamedSplit
from ..packaged_modules.union.union import Union
from ..utils.typing import NestedDataStructureLike


class UnionDatasetReader(AbstractDatasetReader):
    def __init__(
            self,
            path_or_paths: NestedDataStructureLike[str],
            seed: Optional[int] = None,
            split: Optional[NamedSplit] = None,
            features: Optional[Features] = None,
            cache_dir: str = None,
            keep_in_memory: bool = False,
            streaming: bool = False,
            num_proc: Optional[int] = None,
            **kwargs,
    ):
        super().__init__(
            path_or_paths,
            split=split,
            features=features,
            cache_dir=cache_dir,
            keep_in_memory=keep_in_memory,
            streaming=streaming,
            num_proc=num_proc,
            **kwargs)
        data_files = path_or_paths if isinstance(path_or_paths, dict) else {self.split: path_or_paths}
        self.builder = Union(
            seed=seed,
            cache_dir=cache_dir,
            data_files=data_files,
            features=features,
            **kwargs,
        )

    def read(self):
        # Build iterable dataset
        if self.streaming:
            dataset = self.builder.as_streaming_dataset(split=self.split)
        # Build regular (map-style) dataset
        else:
            download_config = None
            download_mode = None
            verification_mode = None
            base_path = None

            self.builder.download_and_prepare(
                download_config=download_config,
                download_mode=download_mode,
                verification_mode=verification_mode,
                # try_from_hf_gcs=try_from_hf_gcs,
                base_path=base_path,
                num_proc=self.num_proc,
            )
            dataset = self.builder.as_dataset(
                split=self.split, verification_mode=verification_mode, in_memory=self.keep_in_memory
            )
        return dataset