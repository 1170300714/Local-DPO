from typing import Optional, Union, Dict

from .abc import AbstractDatasetReader
from .. import Features, NamedSplit
from ..packaged_modules.udf_sql.udf_sql import UdfSql


class UdfSqlDatasetReader(AbstractDatasetReader):
    def __init__(
            self,
            sqls: Union[str, Dict[str, str]],
            project: Optional[str] = None,
            udfs: Optional[Dict] = None,
            split: Optional[NamedSplit] = None,
            features: Optional[Features] = None,
            cache_dir: str = None,
            keep_in_memory: bool = False,
            streaming: bool = False,
            num_proc: Optional[int] = None,
            **kwargs,
    ):
        super().__init__(
            split=split,
            features=features,
            cache_dir=cache_dir,
            keep_in_memory=keep_in_memory,
            streaming=streaming,
            num_proc=num_proc,
            **kwargs)
        sqls = sqls if isinstance(sqls, dict) else {self.split: sqls}
        self.builder = UdfSql(
            sqls=sqls,
            project=project,
            udfs=udfs,
            cache_dir=cache_dir,
            features=features,
            **kwargs,
        )

    def read(self):
        # Build iterable dataset
        if self.streaming:
            dataset = self.builder.as_streaming_dataset(split=self.split)
        # Build regular (map-style) dataset
        else:
            download_config = None
            download_mode = None
            verification_mode = None
            base_path = None

            self.builder.download_and_prepare(
                download_config=download_config,
                download_mode=download_mode,
                verification_mode=verification_mode,
                # try_from_hf_gcs=try_from_hf_gcs,
                base_path=base_path,
                num_proc=self.num_proc,
            )
            dataset = self.builder.as_dataset(
                split=self.split, verification_mode=verification_mode, in_memory=self.keep_in_memory
            )
        return dataset
