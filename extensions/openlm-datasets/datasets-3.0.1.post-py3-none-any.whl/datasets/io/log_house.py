from typing import Optional, Union

from .abc import AbstractDatasetReader
from .. import Features, NamedSplit
from .. import Features
from ..packaged_modules.log_house.log_house import LogHouse


class LogHouseDatasetReader(AbstractDatasetReader):
    def __init__(
            self,
            sqls: Union[str, dict],
            app: str,
            user: str,
            password: str,
            split: Optional[NamedSplit] = None,
            features: Optional[Features] = None,
            cache_dir: str = None,
            keep_in_memory: bool = False,
            **kwargs,
    ):
        super().__init__(split=split, features=features, cache_dir=cache_dir, keep_in_memory=keep_in_memory, **kwargs)
        sqls = sqls if isinstance(sqls, dict) else {self.split: sqls}
        self.builder = LogHouse(
            cache_dir=cache_dir,
            features=features,
            sqls=sqls,
            app=app,
            user=user,
            password=password,
            **kwargs,
        )

    def read(self):
        download_config = None
        download_mode = None
        verification_mode = None
        base_path = None

        self.builder.download_and_prepare(
            download_config=download_config,
            download_mode=download_mode,
            verification_mode=verification_mode,
            # try_from_hf_gcs=try_from_hf_gcs,
            base_path=base_path,
        )

        # Build dataset for splits
        dataset = self.builder.as_dataset(
            split=self.split, verification_mode=verification_mode, in_memory=self.keep_in_memory
        )
        return dataset
