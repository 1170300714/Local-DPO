import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, ClassVar, Dict, Optional, Union

import pyarrow as pa
from .. import config
from ..download.download_config import DownloadConfig
from ..download.streaming_download_manager import xopen
from ..table import array_cast
from ..utils.py_utils import no_op_if_value_is_null, string_to_dict


if TYPE_CHECKING:
    from .features import FeatureType


_ffmpeg_warned, _librosa_warned, _videoread_warned = False, False, False


@dataclass
class Binary:
    """Binary [`Feature`] to extract binary data from an binary file.

    Input: The Binary feature accepts as input:
    - A `str`: Absolute path to the binary file (i.e. random access is allowed).
    - A `dict` with the keys:

        - `path`: String with relative path of the binary file to the archive file.
        - `bytes`: Bytes content of the binary file.

      This is useful for archived files with sequential access.

    Args:
        decode (`bool`, defaults to `True`):
            Whether to decode the binary data. If `False`,
            returns the underlying dictionary in the format `{"path": video_path, "bytes": video_bytes}`.

    Example:

    ```py
    >>> from datasets import load_dataset, Binary
    >>> ds = load_dataset("PolyAI/minds14", name="en-US", split="train")
    >>> ds = ds.cast_column("binary", Binary())
    >>> ds[0]["binary"]
    {'bytes': ...,
     'path': '/root/.cache/huggingface/datasets/downloads/extracted/f14948e0e84be638dd7943ac36518a4cf3324e8b7aa331c5ab11541518e9368c/en-US~JOINT_ACCOUNT/602ba55abb1e6d0fbce92065.wav'}
    ```
    """

    decode: bool = True
    id: Optional[str] = None
    # Automatically constructed
    dtype: ClassVar[str] = "dict"
    pa_type: ClassVar[Any] = pa.struct({"bytes": pa.binary(), "path": pa.string()})
    _type: str = field(default="Binary", init=False, repr=False)

    def __call__(self):
        return self.pa_type

    def encode_example(self, value: Union[str, bytes, dict]) -> dict:
        """Encode example into a format for Arrow.

        Args:
            value (`str` or `dict`):
                Data passed as input to Binary feature.

        Returns:
            `dict`
        """
        if isinstance(value, str):
            return {"bytes": None, "path": value}
        elif isinstance(value, bytes):
            return {"bytes": value, "path": None}
        elif value.get("path") is not None and os.path.isfile(value["path"]):
            return {"bytes": None, "path": value.get("path")}
        elif value.get("bytes") is not None or value.get("path") is not None:
            # store the binary bytes, and path is used to infer the binary format using the file extension
            return {"bytes": value.get("bytes"), "path": value.get("path")}
        else:
            raise ValueError(
                f"An binary sample should have one of 'path' or 'bytes' but they are missing or None in {value}."
            )

    def decode_example(
        self, value: dict, token_per_repo_id: Optional[Dict[str, Union[str, bool, None]]] = None
    ) -> dict:
        """Decode example binary file into binary data.

        Args:
            value (`dict`):
                A dictionary with keys:

                - `path`: String with relative binary file path.
                - `bytes`: Bytes of the binary file.
            token_per_repo_id (`dict`, *optional*):
                To access and decode
                binary files from private repositories on the Hub, you can pass
                a dictionary repo_id (`str`) -> token (`bool` or `str`)

        Returns:
            `dict`
        """
        if not self.decode:
            raise RuntimeError("Decoding is disabled for this feature. Please use Binary(decode=True) instead.")

        path, bytes = (value["path"], value["bytes"])

        if bytes is not None:
            return {"bytes": bytes, "path": path}
        elif path is not None:
            if path.startswith("oss://"):
                from datasets.packaged_modules.odps.oss_util import load_file
                return load_file(path)
            elif path.startswith("ailake://"):
                from datasets.packaged_modules.odps.ailake_table_util import load_file_from_lookup_table
                return load_file_from_lookup_table(path)
            else:
                token_per_repo_id = token_per_repo_id or {}
                source_url = path.split("::")[-1]
                pattern = (
                    config.HUB_DATASETS_URL if source_url.startswith(
                        config.HF_ENDPOINT) else config.HUB_DATASETS_HFFS_URL
                )
                try:
                    repo_id = string_to_dict(source_url, pattern)["repo_id"]
                    token = token_per_repo_id[repo_id]
                except (ValueError, KeyError):
                    token = None

                download_config = DownloadConfig(token=token)
                with xopen(path, "rb", download_config=download_config) as f:
                    bytes = f.read()
                return {"bytes": bytes, "path": path}
        else:
            raise ValueError(f"An binary sample should have one of 'path' or 'bytes' but both are None in {value}.")

    def flatten(self) -> Union["FeatureType", Dict[str, "FeatureType"]]:
        """If in the decodable state, raise an error, otherwise flatten the feature into a dictionary."""
        from .features import Value

        if self.decode:
            raise ValueError("Cannot flatten a decoded Binary feature.")
        return {
            "bytes": Value("binary"),
            "path": Value("string"),
        }

    def cast_storage(self, storage: Union[pa.StringArray, pa.StructArray]) -> pa.StructArray:
        """Cast an Arrow array to the Binary arrow storage type.
        The Arrow types that can be converted to the Binary pyarrow storage type are:

        - `pa.string()` - it must contain the "path" data
        - `pa.binary()` - it must contain the binary bytes
        - `pa.struct({"bytes": pa.binary()})`
        - `pa.struct({"path": pa.string()})`
        - `pa.struct({"bytes": pa.binary(), "path": pa.string()})`  - order doesn't matter

        Args:
            storage (`Union[pa.StringArray, pa.StructArray]`):
                PyArrow array to cast.

        Returns:
            `pa.StructArray`: Array in the Binary arrow storage type, that is
                `pa.struct({"bytes": pa.binary(), "path": pa.string()})`
        """
        if pa.types.is_string(storage.type):
            bytes_array = pa.array([None] * len(storage), type=pa.binary())
            storage = pa.StructArray.from_arrays([bytes_array, storage], ["bytes", "path"], mask=storage.is_null())
        elif pa.types.is_binary(storage.type):
            path_array = pa.array([None] * len(storage), type=pa.string())
            storage = pa.StructArray.from_arrays([storage, path_array], ["bytes", "path"], mask=storage.is_null())
        elif pa.types.is_struct(storage.type):
            if storage.type.get_field_index("bytes") >= 0:
                bytes_array = storage.field("bytes")
            else:
                bytes_array = pa.array([None] * len(storage), type=pa.binary())
            if storage.type.get_field_index("path") >= 0:
                path_array = storage.field("path")
            else:
                path_array = pa.array([None] * len(storage), type=pa.string())
            storage = pa.StructArray.from_arrays([bytes_array, path_array], ["bytes", "path"], mask=storage.is_null())
        return array_cast(storage, self.pa_type)

    def embed_storage(self, storage: pa.StructArray) -> pa.StructArray:
        """Embed binary files into the Arrow array.

        Args:
            storage (`pa.StructArray`):
                PyArrow array to embed.

        Returns:
            `pa.StructArray`: Array in the Binary arrow storage type, that is
                `pa.struct({"bytes": pa.binary(), "path": pa.string()})`.
        """

        @no_op_if_value_is_null
        def path_to_bytes(path):
            with xopen(path, "rb") as f:
                bytes_ = f.read()
            return bytes_

        bytes_array = pa.array(
            [
                (path_to_bytes(x["path"]) if x["bytes"] is None else x["bytes"]) if x is not None else None
                for x in storage.to_pylist()
            ],
            type=pa.binary(),
        )
        path_array = pa.array(
            [os.path.basename(path) if path is not None else None for path in storage.field("path").to_pylist()],
            type=pa.string(),
        )
        storage = pa.StructArray.from_arrays([bytes_array, path_array], ["bytes", "path"], mask=bytes_array.is_null())
        return array_cast(storage, self.pa_type)
