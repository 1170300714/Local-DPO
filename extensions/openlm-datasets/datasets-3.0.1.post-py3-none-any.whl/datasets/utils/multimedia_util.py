def check_media_type(media_type):
    if media_type not in ['IMAGE', 'AUDIO', 'VIDEO', 'BINARY']:
        raise ValueError(f"Invalid media type: {media_type}")


def decode_example(media_type, value):
    from datasets import Image, Video, Audio, Binary

    if media_type == 'IMAGE':
        return Image().decode_example(value)
    elif media_type == 'AUDIO':
        return Audio().decode_example(value)
    elif media_type == 'VIDEO':
        return Video().decode_example(value)
    elif media_type == 'BINARY':
        return Binary().decode_example(value)
    else:
        raise ValueError(f"Invalid media type: {media_type}")
