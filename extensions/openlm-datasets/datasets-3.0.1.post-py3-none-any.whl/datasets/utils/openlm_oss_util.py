import os
import tempfile
import traceback
from typing import Optional, Union, List

import fsspec

from .logging import get_logger
import oss2

from .openlm_client import get_platform_oss_account
from ..config import OPENLM_DATASETS_DOWNLOAD_MAX_THREADS

logger = get_logger(__name__)


def is_path_exist(remote_path, token=None):
    oss_account = get_platform_oss_account(token=token)
    auth = oss2.Auth(oss_account[0], oss_account[1])

    parsed_remote_path = remote_path.replace("oss://", "")
    index = parsed_remote_path.find('/')
    bucket = parsed_remote_path[0:index]
    prefix = parsed_remote_path[index + 1:]
    bucket = oss2.Bucket(auth, oss_account[2], bucket)

    for obj in oss2.ObjectIteratorV2(bucket, prefix=prefix):
        return True
    return False


def download_path_new(remote_path, output_dir, cache_dir,
                      storage_options = None,
                      allow_patterns: Optional[Union[List[str], str]] = None,
                      ignore_patterns: Optional[Union[List[str], str]] = None,
                      max_workers: int = 8,
                      token=None):
    logger.warning("download to {}".format(output_dir))
    os.makedirs(cache_dir, exist_ok=True)

    fs, _, paths = fsspec.get_fs_token_paths(output_dir, storage_options=storage_options)
    if len(paths) > 1:
        raise ValueError(f"output_dir can be at most one path but was {paths}")
    relative_output_dir = paths[0]

    fs.makedirs(relative_output_dir, exist_ok=True)

    oss_account = get_platform_oss_account(token=token)
    auth = oss2.Auth(oss_account[0], oss_account[1])

    parsed_remote_path = remote_path.replace("oss://", "")
    index = parsed_remote_path.find('/')
    bucket = parsed_remote_path[0:index]
    prefix = parsed_remote_path[index + 1:]
    bucket = oss2.Bucket(auth, oss_account[2], bucket)

    total_size = 0
    files = []
    for obj in oss2.ObjectIteratorV2(bucket, prefix=prefix):
        file_relative_path = obj.key.replace(prefix, "")
        if len(file_relative_path) <= 0 or file_relative_path.endswith('/'):
            logger.warning(f"skip download directory {file_relative_path}")
            continue

        files.append((obj.key, file_relative_path, obj.size))
        total_size += obj.size

    from huggingface_hub.utils import filter_repo_objects
    download_file_names = list(
        filter_repo_objects(
            items=[file[1] for file in files],
            allow_patterns=allow_patterns,
            ignore_patterns=ignore_patterns,
        )
    )
    download_files = [file for file in files if file[1] in download_file_names]
    download_size = sum([file[2] for file in download_files])

    logger.warning("download, files: %s/%s, size: %s/%s", len(download_files), len(files), download_size, total_size)

    def process(download_file):
        obj_key, file_relative_path, _ = download_file
        relative_output_file = os.path.join(relative_output_dir, file_relative_path)
        if fs.exists(relative_output_file):
            logger.warning("skip download already exists file: %s", file_relative_path)
            return

        try:
            with tempfile.NamedTemporaryFile(dir=cache_dir) as local_file:
                local_file = local_file.name
                bucket.get_object_to_file(obj_key, local_file)
                fs.makedirs(os.path.dirname(relative_output_file), exist_ok=True)
                fs.put_file(local_file, relative_output_file)
        except Exception as e:
            raise Exception(f"download {file_relative_path} failed, error={traceback.format_exc()}")

    from tqdm.contrib.concurrent import thread_map
    import huggingface_hub.utils.tqdm as hf_tqdm
    thread_map(
        process,
        download_files,
        desc=f"Downloading {len(download_files)} files",
        max_workers=max_workers,
        tqdm_class=hf_tqdm,
    )
    logger.warning("download success")

def download_path(remote_path, local_path, log_detail=True, token=None):
    local_path = os.path.expanduser(local_path)
    logger.warning("download from {} to {}".format(remote_path, local_path))

    oss_account = get_platform_oss_account(token=token)
    auth = oss2.Auth(oss_account[0], oss_account[1])

    parsed_remote_path = remote_path.replace("oss://", "")
    index = parsed_remote_path.find('/')
    bucket = parsed_remote_path[0:index]
    prefix = parsed_remote_path[index + 1:]
    bucket = oss2.Bucket(auth, oss_account[2], bucket)

    total_size = 0
    files = []
    for obj in oss2.ObjectIteratorV2(bucket, prefix=prefix):
        file_relative_path = obj.key.replace(prefix, "")
        if len(file_relative_path) <= 0 or file_relative_path.endswith('/'):
            logger.warning(f"skip download directory {file_relative_path}")
            continue

        local_file = os.path.join(local_path, file_relative_path)
        if not os.path.exists(os.path.dirname(local_file)):
            os.makedirs(os.path.dirname(local_file), exist_ok=True)

        files.append((obj.key, file_relative_path, local_file))
        total_size += obj.size

    download_count = 0
    if total_size > 5 * 1024 * 1024 * 1024 and len(files) > 10 and OPENLM_DATASETS_DOWNLOAD_MAX_THREADS > 1:
        threads = max(2, min(int(len(files) / 5), OPENLM_DATASETS_DOWNLOAD_MAX_THREADS))
        logger.warning("download, total files: %s, total size: %s, threads: %s", len(files), total_size, threads)

        from concurrent.futures import ThreadPoolExecutor
        import threading

        lock = threading.Lock()
        futures = []
        download_counts = [0]

        def process(obj_key, file_relative_path, local_file, lock, download_counts):
            try:
                bucket.get_object_to_file(obj_key, local_file)

                with lock:
                    download_counts[0] += 1
                    if log_detail:
                        logger.warning(f"download {file_relative_path}")
                    elif download_counts[0] % 100 == 0:
                        logger.warning(f"download %s files", download_counts[0])
                return True
            except Exception as e:
                logger.warning(f"download {file_relative_path} failed, error=%s", traceback.format_exc())
                return False

        with ThreadPoolExecutor(max_workers=threads) as pool:
            for (obj_key, file_relative_path, local_file) in files:
                future = pool.submit(process, obj_key, file_relative_path, local_file, lock, download_counts)
                futures.append(future)

            for future in futures:
                if not future.result():
                    raise Exception("download failed")
        download_count = download_counts[0]
    else:
        logger.warning("download, total files: %s, total size: %s", len(files), total_size)

        for (obj_key, file_relative_path, local_file) in files:
            bucket.get_object_to_file(obj_key, local_file)
            download_count += 1

            if log_detail:
                logger.warning(f"download {file_relative_path}")
            elif download_count % 100 == 0:
                logger.warning(f"download %s files", download_count)

    logger.warning("download success, total download files: %s", download_count)


def download_file(remote_file, local_file, token=None):
    local_file = os.path.expanduser(local_file)
    logger.warning("download from {} to {}".format(remote_file, local_file))
    if not os.path.exists(os.path.dirname(local_file)):
        os.makedirs(os.path.dirname(local_file), exist_ok=True)
    if not os.path.exists(local_file):
        import pathlib
        pathlib.Path(local_file).touch()

    oss_account = get_platform_oss_account(token=token)
    auth = oss2.Auth(oss_account[0], oss_account[1])

    parsed_remote_path = remote_file.replace("oss://", "")
    index = parsed_remote_path.find('/')
    bucket = parsed_remote_path[0:index]
    key = parsed_remote_path[index + 1:]
    bucket = oss2.Bucket(auth, oss_account[2], bucket)

    bucket.get_object_to_file(key, local_file)
    logger.warning("download success")


def list_path(remote_path, absolute=False, token=None):
    oss_account = get_platform_oss_account(token=token)
    auth = oss2.Auth(oss_account[0], oss_account[1])

    parsed_remote_path = remote_path.replace("oss://", "")
    index = parsed_remote_path.find('/')
    bucket = parsed_remote_path[0:index]
    prefix = parsed_remote_path[index + 1:]
    bucket = oss2.Bucket(auth, oss_account[2], bucket)

    file_list = []
    for obj in oss2.ObjectIteratorV2(bucket, prefix=prefix, delimiter='/'):
        file_relative_path = obj.key.replace(prefix, "")
        if len(file_relative_path) <= 0:
            continue

        file_list.append(file_relative_path)
    if absolute:
        file_list = [remote_path + file for file in file_list]
    return file_list