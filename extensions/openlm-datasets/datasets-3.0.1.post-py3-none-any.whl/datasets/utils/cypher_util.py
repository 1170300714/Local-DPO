from base64 import b64decode, b64encode

from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

_IV_LENGTH = 16
_KEY = b'a0paescyph3rkey1'


class Cypher:
    @staticmethod
    def hidden(value):
        if value is None:
            return value
        if len(value) <= 2:
            return "*" * len(value)
        elif len(value) <= 6:
            copy_value = list(value)
            for i in range(1, len(copy_value) - 1):
                copy_value[i] = "*"
            return "".join(copy_value)
        elif len(value) <= 12:
            copy_value = list(value)
            for i in range(3, len(copy_value) - 3):
                copy_value[i] = "*"
            return "".join(copy_value)
        else:
            size = int(len(value)/4)
            copy_value = list(value)
            for i in range(size, len(copy_value) - size):
                copy_value[i] = "*"
            return "".join(copy_value)


    @staticmethod
    def encrypt(plain_text, key=_KEY):
        iv = get_random_bytes(_IV_LENGTH)
        cipher = AES.new(key, AES.MODE_CTR, initial_value=iv, nonce=b'')

        if type(plain_text) == str:
            data = plain_text.encode('utf8')
        elif type(plain_text) == bytes:
            data = plain_text
        else:
            data = str(plain_text).encode('utf8')
        ct_bytes = cipher.encrypt(data)
        return b64encode(iv + ct_bytes).decode('utf-8')

    @staticmethod
    def decrypt(cipher_text, key=_KEY):
        decoded_bytes = b64decode(cipher_text)
        iv = decoded_bytes[0:_IV_LENGTH]
        ct_bytes = decoded_bytes[_IV_LENGTH:]
        cipher = AES.new(key, AES.MODE_CTR, initial_value=iv, nonce=b'')
        return cipher.decrypt(ct_bytes).decode('utf8')
