# coding=utf-8

import json
import time
import os
import urllib3

from .logging import get_logger
from .openlm_config import OpenlmConfig
from .cypher_util import Cypher

logger = get_logger(__name__)


def _headers(token=None):
    headers = {
        "Content-Type": "application/json",
        "user-token": token or OpenlmConfig.get_token()
    }
    return headers


def _usage_headers():
    headers = {}

    app_name = os.environ.get("HIPPO_APP", "")
    role_name = os.environ.get("HIPPO_ROLE", "")
    host_ip = os.environ.get("HIPPO_SLAVE_IP", None) or os.environ.get("KUBERNETES_NODE_IP", "")
    job_name = ""
    job_type = os.environ.get("OPENLM_JOB_TYPE", "")
    platform = ""
    ext_info = {}

    if app_name.startswith("xdl-"):
        platform = "nebula"
        mdl_config_file = os.environ.get("MDL_CONFIG_FILE", "")
        if len(mdl_config_file) > 0 and os.path.exists(mdl_config_file):
            try:
                with open(mdl_config_file, "r") as fp:
                    mdl_config = json.load(fp)
                    job_name = mdl_config.get("job_name", "")
                    job_type = mdl_config.get("job_type", "")
                    nebula_model = mdl_config.get("_NEBULA_MODEL", "")
                    if len(nebula_model) > 0:
                        ext_info["nebula_model"] = nebula_model
            except Exception as e:
                logger.warning(f"load {mdl_config_file} failed, err: {str(e)}")
        if len(job_name) <= 0:
            job_name = app_name
    elif app_name.startswith("aop_"):
        platform = "aop"
        job_name = app_name
        job_info_file = "./job_info.json"
        if os.path.exists(job_info_file):
            try:
                with open(job_info_file, "r") as fp:
                    job_info = json.load(fp)
                    ext_info["teamName"] = job_info.get("teamName", None)
            except Exception as e:
                logger.warning(f"load {job_info_file} failed, err: {str(e)}")

    headers["app-name"] = app_name
    headers["role-name"] = role_name
    headers["host-ip"] = host_ip
    headers["platform"] = platform
    headers["job-type"] = job_type
    headers["job-name"] = job_name
    headers["ext-info"] = json.dumps(ext_info)

    return headers


def do_get_request(url, headers=None, token=None):
    if headers is None:
        headers = _headers(token=token)

    timeout = urllib3.Timeout(connect=60.0, read=60.0)
    http = urllib3.PoolManager(timeout=timeout, cert_reqs='CERT_NONE')
    urllib3.disable_warnings()
    response = http.request('GET', url, headers=headers).data.decode('utf-8')
    return response


def _get(action, url, headers=None, token=None):
    logger.debug("%s, url=%s", action, url)
    sleep_time = 30
    retries = 5
    if headers is None:
        headers = _headers(token=token)
    while True:
        response = None
        response_json = None
        try:
            response = do_get_request(url, headers=headers)
            response_json = json.loads(response)

            if "status" not in response_json or int(response_json["status"]) != 0:
                if "error" in response_json and response_json["error"] is not None and len(response_json["error"]) > 0:
                    # don't retry
                    retries = 0
                raise Exception(f"response isn't success, error message: {response_json.get('message', '')}" )
            data = response_json["data"] if 'data' in response_json else None
            logger.debug("%s success, response=%s", action, json.dumps(data, indent=2))
            return data
        except Exception as e:
            retries -= 1
            if retries > 0:
                logger.warning("%s is failed, %s retries left, response=%s, exception=%s", action, retries,
                               json.dumps(response_json, indent=2) if response_json else response, str(e))
                time.sleep(sleep_time)
            else:
                logger.error("%s is failed, response=%s, exception=%s", action,
                             json.dumps(response_json, indent=2) if response_json else response, str(e))
                raise e


def get_server_addr():
    env = OpenlmConfig.get_env()
    if env == 'daily':
        return 'http://localhost:7001'
    elif env == 'pre':
        return 'https://pre-nebula-serivce-mesh.alibaba-inc.com/openlm'
    else:
        return 'https://nebula-service-center.alibaba-inc.com/openlm'


def get_dataset(name, token=None):
    url = get_server_addr() + "/v2/dataset/detail?name={}".format(name)
    response = _get("get dataset", url, token=token)
    return response


def get_dataset_if_exist(name, token=None):
    url = get_server_addr() + "/v2/dataset/detail?name={}&checkExist=true".format(name)
    response = _get("get dataset if exist", url, token=token)
    return response


def is_dataset_exist(name, token=None):
    response = get_dataset_if_exist(name, token=token)
    return response is not None and len(response) > 0


def fetch_version(name, version=None, token=None):
    url = get_server_addr() + "/v2/dataset/version/fetch?name={}&version={}".format(name, version or "")
    headers = _headers(token=token)
    headers.update(_usage_headers())
    response = _get("fetch dataset version", url, headers=headers)
    return response


def get_user_odps_account(user_id=None, token=None):
    url = get_server_addr() + "/v1/user/detail" + ("?userId=" + user_id if user_id else "")
    response = _get("get user", url, token=token)
    return response["odpsAccount"]


def get_project_odps_account(name, user_id=None, token=None):
    url = get_server_addr() + "/v1/project/detail?name={}&userId={}".format(name, user_id)
    response = _get("get project", url, token=token)
    return response["odpsAccount"]


def get_platform_odps_account(token=None):
    url = get_server_addr() + "/v1/platform/odps_account"
    response = _get("get platform odps account", url, token=token)
    return response


def get_platform_oss_account(token=None):
    url = get_server_addr() + "/v1/platform/oss_account"
    response = _get("get oss", url, token=token)
    access_id = Cypher.decrypt(response["access_id"])
    access_key = Cypher.decrypt(response["access_key"])
    end_point = response["end_point"]
    return access_id, access_key, end_point


def list_udf(project, token=None):
    url = get_server_addr() + "/v2/dataset/udf/list?projectName={}".format(project)
    response = _get("list udf", url, token=token)
    return response


def get_udf(id, token=None):
    url = get_server_addr() + "/v2/dataset/udf/detail?id={}".format(id)
    response = _get("get udf", url, token=token)
    return response
