# coding=utf-8

import json
import os
from typing import Optional

from .. import config


class OpenlmConfig:
    path_config = os.path.join(config.OPENLM_HOME, ".openlm_config.json")

    @classmethod
    def get_token(cls) -> Optional[str]:
        token = cls._get_config("OPENLM_TOKEN")
        if token is None or len(token) <= 0:
            raise Exception("OPENLM_TOKEN isn't set")
        return token

    @classmethod
    def get_env(cls) -> Optional[str]:
        env = cls._get_config("OPENLM_ENV")
        if env is None or len(env) <= 0:
            return ""
        else:
            return env

    @classmethod
    def _get_config(cls, name) -> Optional[str]:
        # 1. Is it set by environment variable ?
        value: Optional[str] = os.environ.get(name)
        if value is None or len(value) <= 0:
            # 2. Is it set in token path ?
            try:
                with open(cls.path_config, "r") as fp:
                    config = json.load(fp)
                    value = config.get(name, "")
            except FileNotFoundError:
                value = None

        if value is None or len(value) <= 0:
            return None
        return value
