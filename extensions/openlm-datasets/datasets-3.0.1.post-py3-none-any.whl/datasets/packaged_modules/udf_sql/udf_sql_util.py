import os
import shutil
import sys
import importlib
import inspect

from ...dataset_dict import DatasetDict
from ...utils.openlm_client import get_udf, list_udf
from ...utils.openlm_oss_util import download_file
from ...utils.filelock import FileLock
from ...features import features
from ...utils.logging import get_logger

logger = get_logger(__name__)


def cache_udf_code(local_root_path, backup_path):
    os.makedirs(local_root_path, exist_ok=True)
    local_init_file = os.path.join(local_root_path, "../../__init__.py")
    if not os.path.exists(local_init_file):
        with open(local_init_file, "w") as fp:
            pass

    code_dir_name = os.path.basename(backup_path).replace(".zip", "")
    local_code_dir = os.path.join(local_root_path, code_dir_name)
    local_lock_path = local_code_dir + ".lock"
    with FileLock(local_lock_path):
        if not os.path.exists(local_code_dir):
            local_incomplete_dir = os.path.join(os.path.dirname(local_code_dir),
                                                os.path.basename(local_code_dir) + ".incomplete")
            if os.path.exists(local_incomplete_dir):
                shutil.rmtree(local_incomplete_dir)

            local_code_file = os.path.join(local_root_path, os.path.basename(backup_path))
            if os.path.exists(local_code_file):
                os.remove(local_code_file)
            download_file(backup_path, local_code_file)
            import zipfile
            with zipfile.ZipFile(local_code_file, "r") as zip_file:
                zip_file.extractall(local_incomplete_dir)
                zip_file.close()

            os.remove(local_code_file)
            os.rename(local_incomplete_dir, local_code_dir)
    return code_dir_name


def load_project_udfs(project, sql_udf_names):
    project_udfs = list_udf(project)
    local_root_path = os.path.join("/tmp/datasets/udfs")

    udfs = {}
    sys.path.append(local_root_path)
    for project_udf in project_udfs:
        udf_detail = get_udf(project_udf["id"])
        backup_path = udf_detail["backupPath"]
        code_file = udf_detail["codeFile"]
        udf_name = udf_detail["udfName"]
        if not udf_name.upper() in sql_udf_names:
            continue
        logger.warning("load udf %s in project %s ...", udf_name, project)

        dir_name = cache_udf_code(local_root_path, backup_path)
        module_name = dir_name + '.' + '.'.join(code_file.replace(".py", "").split('/'))
        module = importlib.import_module(module_name)
        udf = module.__dict__.get(udf_name, None)
        if udf is None:
            raise Exception(f"udf {udf_name} is not found in {code_file}")

        if not inspect.isfunction(udf):
            raise Exception(f"udf {udf_name} in {code_file} is not a function, but a {type(udf)}")
        udfs[udf_name.upper()] = udf
    return udfs


def parse_table_name(name):
    if name is None or len(name.strip()) <= 0:
        raise Exception(f"empty name: {name}")

    items = []

    name_parts = name.split(';')
    for name_part in name_parts:
        tmps = name_part.split(':')
        if len(tmps) == 1:
            items.append((tmps[0], None, None))
        elif len(tmps) == 2:
            items.append((tmps[0], tmps[1], None))
        elif len(tmps) == 3:
            items.append((tmps[0], tmps[1], tmps[2]))
        else:
            raise Exception(f"invalid name: {name_part}, should be format: DATASET_NAME[:CONFIG_NAME[:SPLIT_NAME]]")

    logger.warning("name: %s, parsed: %s", name, items)
    return items


def load_table_data(name):
    items = parse_table_name(name)

    dataset_list = []
    for item in items:
        dataset_name, config_name, split_name = item
        config_names = []
        if config_name is None or len(config_name) <= 0:
            from ...inspect import get_dataset_config_names
            config_names = get_dataset_config_names(dataset_name)
        else:
            config_names.append(config_name)

        for config_name in config_names:
            logger.warning("load data, dataset_name: %s, config_name: %s, split_name: %s",
                           dataset_name, config_name, split_name)
            from ...load import load_dataset
            dataset = load_dataset(dataset_name, name=config_name, split=split_name)
            if isinstance(dataset, DatasetDict):
                dataset_list.extend(dataset.values())
            else:
                dataset_list.append(dataset)

    table = []
    features = None
    for dataset in dataset_list:
        if features:
            if features != dataset.features:
                raise Exception("mismatch features, expected: %s, auctual: %s", features, dataset.features)
        else:
            features = dataset.features

        for data in dataset:
            table.append(data)

    logger.warning("name: %s, size: %d", name, len(table))
    return table


def parse_udfs_from_sql(sql):
    from sqlglot import parse_one, exp
    udfs_names = set()
    for func in parse_one(sql).find_all(exp.Func):
        if func.alias_or_name and len(func.alias_or_name)>0:
            udfs_names.add(func.alias_or_name.upper())
        else:
            udfs_names.add(func.key.upper())
    return udfs_names


def execute_sql(sql, udfs=None, dialect="mysql"):
    from sqlglot.executor import execute
    from sqlglot import parse_one, exp
    table_datas = {}
    for table in parse_one(sql).find_all(exp.Table):
        name = table.name
        table_data = load_table_data(name)
        table_datas[name] = table_data

    return execute(sql, read=dialect, tables=table_datas, env=udfs)


def infer_feature(data):
    if isinstance(data, int):
        return features.Value(dtype="int64")
    elif isinstance(data, float):
        return features.Value(dtype="float64")
    elif isinstance(data, str):
        return features.Value(dtype="string")
    elif isinstance(data, dict):
        return features.Features({key: infer_feature(value) for key, value in data.items()})
    elif isinstance(data, (tuple, list)):
        single_data = data[0]
        return features.Sequence(infer_feature(single_data))
    else:
        return features.Value(dtype="string")


def infer_features(columns, values):
    data = {}
    for column in columns:
        data[column] = values[column]
    features = infer_feature(data)
    return features
