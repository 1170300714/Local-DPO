from dataclasses import dataclass
from typing import Optional, Dict, Union

import datasets
import datasets.config
import pyarrow as pa
from ...features import features
from ...table import table_cast
from .udf_sql_util import execute_sql, infer_features, load_project_udfs, parse_udfs_from_sql

logger = datasets.utils.logging.get_logger(__name__)


@dataclass
class UdfSqlConfig(datasets.BuilderConfig):
    """BuilderConfig for udf sql."""
    sqls: Dict[str, str] = None
    project: Optional[str] = None
    udfs: Optional[Dict] = None
    features: Optional[datasets.Features] = None
    _split_tables = None

    def __post_init__(self):
        self.sqls = self.sqls if isinstance(self.sqls, dict) else {"train": self.sqls}
        logger.warning("project: %s, udfs:%s, features: %s", self.project, self.udfs, self.features)

        sql_udf_names = set()
        for split_name, split_sql in self.sqls.items():
            if not isinstance(split_sql, str):
                raise Exception(f"invalid type of split sql: {split_sql}")

            logger.warning("split: %s, sql: %s", split_name, split_sql)
            sql_udf_names.update(parse_udfs_from_sql(split_sql))

        if self.project:
            project_udfs = load_project_udfs(self.project, sql_udf_names)
            if self.udfs:
                for name, udf in project_udfs.items():
                    if name in self.udfs:
                        logger.warning("****** project udf %s has been overrided ******", name)
                        pass
                    else:
                        self.udfs[name] = udf
            else:
                self.udfs = project_udfs

    def create_config_id(
            self,
            config_kwargs: dict,
            custom_features: Optional[datasets.Features] = None,
    ) -> str:
        config_kwargs = config_kwargs.copy()
        # We need to stringify the Selectable object to make its hash deterministic
        return super().create_config_id(config_kwargs, custom_features=custom_features)


class UdfSql(datasets.ArrowBasedBuilder):
    BUILDER_CONFIG_CLASS = UdfSqlConfig

    def _info(self):
        return datasets.DatasetInfo(features=self.config.features)

    def _prepare_tables(self):
        split_tables = {}
        for split_name, split_sql in self.config.sqls.items():
            if not isinstance(split_sql, str):
                raise Exception(f"invalid type of split sql: {split_sql}")

            logger.warning("begin to execute sql, split: %s", split_name)
            table = execute_sql(split_sql, udfs=self.config.udfs)
            logger.warning("end to execute sql, split: %s, columns: %s, size: %s", split_name, table.columns, len(table))

            if len(table) <= 0:
                raise Exception(f"split sql result is empty")
            split_tables[split_name] = table

        if self.config.features is None:
            logger.warning("check if features can be aligned between splits")
            split_features_list = [infer_features(table.columns, table[0]) for split_name, table in
                                   split_tables.items()]

            features._check_if_features_can_be_aligned(split_features_list)
            name2feature = {}
            for split_features in split_features_list:
                for k, v in split_features.items():
                    if k not in name2feature or (
                            isinstance(name2feature[k], features.Value) and name2feature[k].dtype == "null"):
                        name2feature[k] = v
            self.config.features = features.Features(name2feature)
        else:
            for split_name, table in split_tables.items():
                for column_name in table.columns:
                    if column_name not in self.config.features:
                        raise Exception(f"column {column_name} in split {split_name} isn't exists in features")

        logger.warning("final features: %s", self.config.features)
        return split_tables

    def _split_generators(self, dl_manager):
        split_tables = self._prepare_tables()
        splits = []
        for split_name, split_table in split_tables.items():
            splits.append(datasets.SplitGenerator(name=split_name, gen_kwargs={
                "split_name": split_name,
                "split_table": split_table
            }))
        return splits

    def _cast_table(self, pa_table: pa.Table) -> pa.Table:
        if self.config.features is not None:
            # adding missing columns
            for column_name in set(self.config.features) - set(pa_table.column_names):
                type = self.config.features.arrow_schema.field(column_name).type
                pa_table = pa_table.append_column(column_name, pa.array([None] * len(pa_table), type=type))
            # more expensive cast to support nested structures with keys in a different order
            # allows str <-> int/float or str to Audio for example
            pa_table = table_cast(pa_table, self.config.features.arrow_schema)
        return pa_table

    def _generate_tables(self, split_name, split_table):
        columns = split_table.columns
        for row_idx, row in enumerate(split_table):
            data = {column: row[column] for column in columns}
            pa_table = pa.Table.from_pylist([data])
            yield row_idx, self._cast_table(pa_table)
