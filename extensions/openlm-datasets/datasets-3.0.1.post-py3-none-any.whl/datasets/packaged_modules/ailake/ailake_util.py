import datasets


def ailake_type_to_feature_type(type):
    type = type.upper()
    if type == "STRING" or "VARCHAR" in type:
        return datasets.Value(dtype="string")
    elif type == "TINYINT":
        return datasets.Value(dtype="int8")
    elif type == "SMALLINT":
        return datasets.Value(dtype="int16")
    elif type == "INT":
        return datasets.Value(dtype="int32")
    elif type == "BIGINT":
        return datasets.Value(dtype="int64")
    elif type == "FLOAT":
        return datasets.Value(dtype="float32")
    elif type == "DOUBLE":
        return datasets.Value(dtype="float64")
    elif type == "DECIMAL":
        return datasets.Value(dtype="decimal128")
    elif type == "BINARY":
        return datasets.Value(dtype="binary")
    elif type == "DATETIME":
        return datasets.Value(dtype="date64")
    elif type == "TIMESTAMP":
        return datasets.Value(dtype="timestamp[ns]")
    elif type == "BOOLEAN":
        return datasets.Value(dtype="bool")
    elif type == "IMAGE":
        return datasets.Image()
    elif type == "AUDIO":
        return datasets.Audio()
    elif type == "VIDEO":
        return datasets.Video()
    elif type == "JSONOBJECT" or type == "JSON":
        return {}
    elif type == "JSONARRAY":
        return [datasets.Value(dtype="string")]
    elif "ARRAY" in type:
        array_count = type.count("ARRAY")
        sub_type = type.replace("ARRAY", "").replace("<", "").replace(">", "")

        if sub_type == "STRING" or "VARCHAR" in type:
            feature = datasets.Value(dtype="string")
        elif sub_type == "TINYINT":
            feature = datasets.Value(dtype="int8")
        elif sub_type == "SMALLINT":
            feature = datasets.Value(dtype="int16")
        elif sub_type == "INT":
            feature = datasets.Value(dtype="int32")
        elif sub_type == "BIGINT":
            feature = datasets.Value(dtype="int64")
        elif sub_type == "FLOAT":
            feature = datasets.Value(dtype="float32")
        elif sub_type == "DOUBLE":
            feature = datasets.Value(dtype="float64")
        elif sub_type == "BINARY":
            feature = datasets.Value(dtype="binary")
        elif sub_type == "":
            feature = datasets.Value(dtype="string")
        elif sub_type == "IMAGE":
            feature = datasets.Image()
        elif sub_type == "AUDIO":
            feature = datasets.Audio()
        elif sub_type == "VIDEO":
            feature = datasets.Video()
        else:
            raise ValueError("unknown ailake array sub type: {}".format(sub_type))

        for i in range(array_count):
            feature = [feature]
        return feature
    else:
        raise ValueError("unknown ailake column type: {}".format(type))


def merge_columns_with_special_column_types(columns, special_column_types):
    pre_processors = {}
    if special_column_types is None:
        return columns, pre_processors

    columns_new = {}
    for column_name, column_type in columns.items():
        if column_name in special_column_types:
            target_column_type = special_column_types[column_name]
            if target_column_type.upper() == "IMAGE":
                if column_type.upper() == "BINARY":
                    columns_new[column_name] = target_column_type
                else:
                    raise ValueError(
                        f"can't transform {column_name} from {column_type} to {target_column_type}")
            elif "IMAGE" in target_column_type.upper():
                if "BINARY" in column_type.upper() and column_type.upper().replace("BINARY", "IMAGE") == target_column_type.upper():
                    columns_new[column_name] = target_column_type
                else:
                    raise ValueError(
                        f"can't transform {column_name} from {column_type} to {target_column_type}")
            else:
                raise ValueError(f"not supported special column type: {column_name}={target_column_type}")
        else:
            columns_new[column_name] = column_type

    for column_name, column_type in special_column_types.items():
        if column_name not in columns:
            raise ValueError(f"unknown column {column_name} in special_column_types: {special_column_types}, "
                            f"all columns: {list(columns.keys())}")
    return columns_new, pre_processors


def _get_ailake_meta_info(ailake_path):
    from lake.table import ScanTableReader
    lake_config = lake_path_to_lake_config(ailake_path)
    reader = ScanTableReader(lake_config, 1)
    reader.open_slice(0, 1)
    column_names, column_type = reader.get_schema()
    columns = {column_name: column_type for column_name, column_type in zip(column_names, column_type)}
    count = reader.count_records()
    reader.close()
    return columns, count


def get_ailake_meta_info(ailake_path):
    try:
        import concurrent.futures
        with concurrent.futures.ProcessPoolExecutor(1) as executor:
            future = executor.submit(_get_ailake_meta_info, ailake_path)
            concurrent.futures.wait([future])
            columns, count = future.result()
    except AssertionError as e:
        if "daemonic processes are not allowed to have children" in str(e):
            columns, count = _get_ailake_meta_info(ailake_path)
        else:
            raise e
    return columns, count


def lake_path_to_lake_meta(lake_path):
    """
        输入类型：
        ailake://lzd_test
        ailake://my_project/lzd_test
        ailake://my_project/lzd_test/partition=tianhe
        ailake://my_project/lzd_test/cluster=ea120
        ailake://my_project/lzd_test/partition=tianhe/cluster=ea120
        ailake://my_project/lzd_test/partition=tianhe/cluster=ea120/family=new
        """
    # 不支持pangu开头的地址输入，必须使用ailake开头的地址
    if lake_path.startswith("pangu://"):
        raise ValueError("path starting with pangu:// are not supported")

    # 必须是pangu或者ailake开头
    if not lake_path.startswith("ailake://"):
        raise ValueError(f"lake_path:{lake_path} not start with ailake://")

    # 去掉前缀
    lake_name = lake_path[9:]

    # 去掉结尾空格和'/'，再分割'/'
    lake_prefixs = lake_name.strip().strip('/').split('/')
    # 查一下分割后是否有空
    for _prefix in lake_prefixs:
        if not _prefix:
            raise ValueError(f'Incorrect ailake path: {lake_path}')

    if len(lake_prefixs) < 1:
        raise ValueError(f'Incorrect ailake path: {lake_path}')

    cluster_name = "ea120"  # 默认存放在ea120
    project_name = ""
    partition_name = "after_union"  # 无分区时设置的默认分区
    family_name = "default"  # 无column_family时设置默认值
    lake_name = ""
    if len(lake_prefixs) == 1:
        raise ValueError('project_name and lake_name must be input')
    elif len(lake_prefixs) == 2:
        # 写俩就是project_name和lake_name
        project_name, lake_name = lake_prefixs
    elif len(lake_prefixs) in (3, 4, 5):
        # 写三个就是project_name, lake_name和补充信息
        project_name, lake_name = lake_prefixs[0], lake_prefixs[1]

        for _tmp_extra_data in lake_prefixs[2:]:
            _key, _value = _tmp_extra_data.split('=')
            if _key not in ('partition', 'cluster', 'family'):
                raise ValueError(f'Incorrect ailake extra key: {lake_path}')

            if _key == 'partition':
                partition_name = _value

            if _key == 'family':
                family_name = _value

            if _key == 'cluster':
                cluster_name = _value
    else:
        raise ValueError(f'Incorrect ailake path: {lake_path}')

    return {
        'cluster': cluster_name,
        'project': project_name,
        'lake': lake_name,
        'family': family_name,
        'partition': partition_name,
    }


def lake_path_to_lake_config(lake_path):
    from lake.reader_config import TablePathConfig

    lake_meta = lake_path_to_lake_meta(lake_path)
    table_path_config = TablePathConfig(lake_meta['cluster'],
                                        lake_meta['project'],
                                        lake_meta['lake'],
                                        lake_meta['family'],
                                        f"{lake_meta['partition']}/data")

    return table_path_config
