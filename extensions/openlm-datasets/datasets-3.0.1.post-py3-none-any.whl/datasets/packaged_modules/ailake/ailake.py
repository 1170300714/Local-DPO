import copy
import time
from dataclasses import dataclass
from typing import Optional

import datasets
import datasets.config
import pyarrow as pa
from datasets.features.features import require_storage_cast
from datasets.table import table_cast

from .ailake_items import AilakeItem, AilakeItemList, AilakeItemDict
from .ailake_util import get_ailake_meta_info, merge_columns_with_special_column_types, \
    ailake_type_to_feature_type
from ..odps.odps_util import row_count_of_shards, get_multimedia_types, shard_rows, \
    skip_data_for_sharding

logger = datasets.utils.logging.get_logger(__name__)


@dataclass
class AilakeConfig(datasets.BuilderConfig):
    """BuilderConfig for Ailake."""
    ailake_item_dict: AilakeItemDict = None
    buffer_size: int = None
    num_workers: int = None
    world_size: int = None
    rank: int = None
    drop_left: bool = False
    features: Optional[datasets.Features] = None

    def __post_init__(self):
        pre_file = None
        pre_columns = None
        columns_cache = {}
        self.ailake_item_dict = AilakeItemDict()
        for split_name, split_data_files in self.data_files.items():
            if isinstance(split_data_files, str):
                split_data_files = [split_data_files]

            split_ailake_item_list: AilakeItemList = AilakeItemList()

            for data_file in split_data_files:
                ailake_item: AilakeItem = AilakeItem.parse(data_file)

                if self.buffer_size:
                    ailake_item.buffer_size = self.buffer_size

                logger.warning("split: %s, ailake_item: %s", split_name, ailake_item.format())

                columns_cache_key = f"{ailake_item.project}.{ailake_item.lake}.{ailake_item.family}"
                if columns_cache_key in columns_cache:
                    columns = copy.deepcopy(columns_cache[columns_cache_key])
                else:
                    columns, _ = get_ailake_meta_info(ailake_item.ailake_path())
                    columns_cache[columns_cache_key] = copy.deepcopy(columns)

                if ailake_item.columns:
                    for column in ailake_item.columns:
                        if column not in columns:
                            raise ValueError(
                                f"column {column} not in {ailake_item.ailake_path()}, all columns={columns}")
                    columns = {key: value for key, value in columns.items() if key in ailake_item.columns}
                elif ailake_item.ignore_columns:
                    for ignore_column in ailake_item.ignore_columns:
                        if ignore_column not in columns:
                            raise ValueError(
                                f"ignore_column {ignore_column} not in {ailake_item.ailake_path()}, all columns={columns}")
                    columns = {key: value for key, value in columns.items() if key not in ailake_item.ignore_columns}
                columns, pre_processors = merge_columns_with_special_column_types(columns,
                                                                                  ailake_item.special_column_types)
                ailake_item._pre_processors = pre_processors

                if pre_columns and pre_columns != columns:
                    raise ValueError("mismatch schema, path1={}, schema1={}, path2={}, schema2={}".format(
                        pre_file, pre_columns, data_file, columns))
                else:
                    pre_file = data_file
                    pre_columns = columns

                split_ailake_item_list.append(ailake_item)

            self.ailake_item_dict[split_name] = AilakeItemList(
                sorted(split_ailake_item_list, key=lambda x: (x.project, x.lake, x.cluster, x.family, x.partition)))

        if self.features is None:
            self.features = datasets.Features({column_name: ailake_type_to_feature_type(column_type)
                                               for column_name, column_type in pre_columns.items()})

            types = get_multimedia_types(self.features.to_dict())
            default_buffer_size = 1000
            if "Video" in types:
                default_buffer_size = 10
            elif "Audio" in types:
                default_buffer_size = 50
            elif "Image" in types:
                default_buffer_size = 100
            for split_name, split_ailake_items in self.ailake_item_dict.items():
                for ailake_item in split_ailake_items:
                    if ailake_item.buffer_size is None:
                        ailake_item.buffer_size = default_buffer_size

    def create_config_id(
            self,
            config_kwargs: dict,
            custom_features: Optional[datasets.Features] = None,
    ) -> str:
        config_kwargs = config_kwargs.copy()
        # We need to stringify the Selectable object to make its hash deterministic
        config_kwargs["ailake_item"] = self.ailake_item_dict.format()

        return super().create_config_id(config_kwargs, custom_features=custom_features)


class Ailake(datasets.ArrowBasedBuilder):
    BUILDER_CONFIG_CLASS = AilakeConfig

    def _info(self):
        return datasets.DatasetInfo(features=self.config.features)

    def _split_generators(self, dl_manager):
        splits = []
        split_infos = datasets.SplitDict()
        for split_name, split_ailake_items in self.config.ailake_item_dict.items():
            split_shards = []
            split_ailake_columns = []
            split_buffer_sizes = []
            split_row_count = 0

            def shard_ailake_item(ailake_item):
                start = time.time()
                table_path = ailake_item.ailake_path()
                columns, row_count = get_ailake_meta_info(table_path)

                buffer_size = ailake_item.buffer_size
                if buffer_size is None or buffer_size <= 0:
                    buffer_size = min(10000, max(int(row_count / 10), 100))

                shards = shard_rows(ailake_item.ailake_path(), row_count,
                                    start=ailake_item.start,
                                    end=ailake_item.end,
                                    num_workers=self.config.num_workers,
                                    world_size=self.config.world_size,
                                    rank=self.config.rank,
                                    drop_left=self.config.drop_left,
                                    num_proc=dl_manager.download_config.num_proc)
                if ailake_item.skip_data_length > 0:
                    shards = skip_data_for_sharding(shards, ailake_item.skip_data_length)

                if ailake_item.columns:
                    columns = {key: value for key, value in columns.items() if key in ailake_item.columns}
                elif ailake_item.ignore_columns:
                    columns = {key: value for key, value in columns.items() if key not in ailake_item.ignore_columns}

                logger.warning(
                    "split: %s, ailake_path: %s, rows: %s, columns: %s, buffer_size: %s, "
                    "num_shards: %s, actual_rows(rows of shards): %s, time_elapsed: %ss",
                    split_name, ailake_item.ailake_path(),
                    row_count, columns, buffer_size, len(shards), row_count_of_shards(shards), int(time.time() - start))

                return shards, columns, buffer_size, row_count_of_shards(shards)

            for item_idx, ailake_item in enumerate(split_ailake_items):
                shards, columns, buffer_size, row_count = shard_ailake_item(ailake_item)
                split_shards.extend([(item_idx, shard_idx, *shard) for shard_idx, shard in enumerate(shards)])
                split_ailake_columns.append(columns)
                split_buffer_sizes.append(buffer_size)
                split_row_count += row_count

            splits.append(
                datasets.SplitGenerator(name=split_name, gen_kwargs={
                    "ailake_items": tuple(split_ailake_items),
                    "ailake_columns": tuple(split_ailake_columns),
                    "buffer_sizes": tuple(split_buffer_sizes),
                    "shards": split_shards}))
            split_infos[split_name] = datasets.SplitInfo(name=split_name, num_examples=split_row_count)
        self.info.splits = split_infos
        self.cheap_cast = all(not require_storage_cast(feature) for feature in self.config.features.values())
        return splits

    def _cast_table(self, pa_table: pa.Table) -> pa.Table:
        if self.config.features is not None:
            schema = self.config.features.arrow_schema
            if self.cheap_cast:
                # cheaper cast
                pa_table = pa.Table.from_arrays([pa_table[field.name] for field in schema], schema=schema)
            else:
                # more expensive cast; allows str <-> int/float or str to Audio for example
                pa_table = table_cast(pa_table, schema)
        return pa_table

    @staticmethod
    def _get_process_name():
        import sys
        rank = None
        try:
            import torch.distributed
            rank = "rank_" + str(torch.distributed.get_rank())
        except:
            pass

        worker = "main"
        if "torch" in sys.modules:
            import torch.utils.data

            worker_info = torch.utils.data.get_worker_info()
            if worker_info is not None:
                worker = "worker_" + str(worker_info.id)
        return rank + "_" + worker if rank else worker

    def _generate_tables(self, ailake_items, ailake_columns, buffer_sizes, shards):
        row_count = 0
        for item_idx, shard_idx, start, stop in shards:
            row_count += stop - start
        cur_row_count = 0
        log_time_interval = 300
        last_log_time = -1
        log_row_interval = max(1, min(int(row_count / 10), 10000))
        last_log_row_step = -1
        process_name = self._get_process_name()

        logger.warning("%s - begin to read, num_shards: %s, rows: %s/%s, shards: %s",
                       process_name, len(shards), cur_row_count, row_count, shards)

        for idx, (item_idx, shard_idx, start, stop) in enumerate(shards):
            ailake_item = ailake_items[item_idx]
            columns = ailake_columns[item_idx]
            buffer_size = buffer_sizes[item_idx]

            table_path = ailake_item.ailake_path()
            from lake.table import ScanTableReader
            from lake.reader_config import PrefetchConfig
            from datasets.packaged_modules.ailake.ailake_util import lake_path_to_lake_config

            lake_config = lake_path_to_lake_config(table_path)
            prefetch_config = PrefetchConfig()
            reader = ScanTableReader(lake_config, buffer_size, select_cols=list(columns.keys()),
                                     prefetch_config=prefetch_config)
            reader.open(start, stop)

            row_idx = start
            while True:
                if reader.reach_end():
                    reader.close()
                    break

                records = reader.read_lines()
                cur_row_count += len(records)
                cur_time = time.time()
                if cur_row_count // log_row_interval != last_log_row_step or (
                        cur_time - last_log_time) > log_time_interval:
                    logger.warning("%s - table_path: %s, shards: %s/%s, rows: %s/%s, progress: %.1f%%",
                                   process_name, ailake_item.ailake_path(), idx + 1, len(shards), cur_row_count,
                                   row_count, 100 * cur_row_count / row_count)
                    last_log_row_step = cur_row_count // log_row_interval
                    last_log_time = cur_time

                datas = []
                for i in range(len(records)):
                    record = records[i]
                    data = {key: value for key, value in zip(columns, record)}
                    data = self._process(ailake_item._pre_processors, data)
                    datas.append(data)
                pa_table = pa.Table.from_pylist(datas)
                yield (item_idx, row_idx), self._cast_table(pa_table)
                row_idx += 1
        logger.warning("%s - end to read, num_shards: %s, rows: %s/%s, shards: %s",
                       process_name, len(shards), cur_row_count, row_count, shards)

    def _process(self, pre_processors, data):
        if pre_processors is not None and len(pre_processors) > 0:
            for name, pre_processor in pre_processors.items():
                if name in data:
                    value = pre_processor(data[name])
                    data[name] = value
        return self._process_example(data)

    # can be override by user
    def _process_example(self, data):
        return data
