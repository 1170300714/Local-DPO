from typing import List, Dict, Optional, Union

import datasets
from datasets.packaged_modules.ailake.ailake_util import lake_path_to_lake_meta

logger = datasets.utils.logging.get_logger(__name__)


class AilakeItem:
    project: str = None
    lake: str = None
    cluster: str = None
    family: str = None
    partition: str = None
    buffer_size: int = None
    # TODO:Later, need to provide a complete dataset failvoer solution
    skip_data_length: int = 0
    special_column_types: Optional[Union[str, Dict]] = None
    columns: Optional[Union[str, List[str]]] = None
    ignore_columns: Optional[Union[str, List[str]]] = None
    start: int = None
    end: int = None
    _pre_processors: Dict = None

    @staticmethod
    def parse_special_column_types(special_column_types):
        if special_column_types is None:
            return None
        if isinstance(special_column_types, str):
            mapping = {}
            for kv in special_column_types.split(','):
                if '=' in kv:
                    tmp = kv.split('=')
                else:
                    tmp = kv.split(':')
                if len(tmp) != 2:
                    raise ValueError(f"invalid special_column_types={special_column_types}")
                mapping[tmp[0].strip()] = tmp[1].strip()
            return mapping
        elif isinstance(special_column_types, dict):
            return special_column_types
        else:
            raise ValueError(
                f"not supported type={type(special_column_types)} of special_column_types={special_column_types}")

    @staticmethod
    def parse_columns(columns):
        if columns is None:
            return None
        if isinstance(columns, str):
            return [column.strip() for column in columns.split(',')]
        elif isinstance(columns, (tuple, list)):
            return columns
        else:
            raise ValueError(
                f"not supported type={type(columns)} of columns={columns}")

    @staticmethod
    def parse(param):
        ailake_item = AilakeItem()

        if isinstance(param, dict):
            ailake_item.project = param.get("project", None)
            ailake_item.lake = param.get("lake", None)
            ailake_item.cluster = param.get("cluster", None)
            ailake_item.family = param.get("family", None)
            ailake_item.partition = param.get("partition", None)
            ailake_item.buffer_size = param.get("buffer_size", None)
            if ailake_item.buffer_size is not None:
                ailake_item.buffer_size = int(ailake_item.buffer_size)
            ailake_item.special_column_types = AilakeItem.parse_special_column_types(
                param.get("special_column_types", None))
            ailake_item.start = param.get("start", None)
            ailake_item.end = param.get("end", None)
            ailake_item.columns = AilakeItem.parse_columns(param.get("columns", None))
            ailake_item.ignore_columns = AilakeItem.parse_columns(param.get("ignore_columns", None))
        elif isinstance(param, str):
            pos = param.find('?')
            prefix = param if pos < 0 else param[:pos]

            lake_meta = lake_path_to_lake_meta(prefix)
            ailake_item.project = lake_meta.get("project", None)
            ailake_item.lake = lake_meta.get("lake", None)
            ailake_item.cluster = lake_meta.get("cluster", None)
            ailake_item.family = lake_meta.get("family", None)
            ailake_item.partition = lake_meta.get("partition", None)

            from urllib.parse import parse_qs, urlparse
            parsed_url = urlparse(param)
            url_params = parse_qs(parsed_url.query)

            for key, value in url_params.items():
                if len(value) > 1:
                    raise ValueError("multiple value is set for parameter: {}={}".format(key, value))
                value = value[0]
                if value is None:
                    continue
                if key == "buffer_size":
                    ailake_item.buffer_size = int(value)
                elif key == "skip_data_length":
                    ailake_item.skip_data_length = int(value)
                elif key == "special_column_types":
                    ailake_item.special_column_types = AilakeItem.parse_special_column_types(value)
                elif key == "columns":
                    ailake_item.columns = AilakeItem.parse_columns(value)
                elif key == "ignore_columns":
                    ailake_item.ignore_columns = AilakeItem.parse_columns(value)
                elif key == "start":
                    ailake_item.start = int(value)
                elif key == "end":
                    ailake_item.end = int(value)
                else:
                    logger.warning("skip unknown parameter: {}={}".format(key, value))
        else:
            raise ValueError(f"parse ailake item failed, unknown type {type(param)}, params={param}")

        if not ailake_item.project:
            raise ValueError("project isn't set")
        if not ailake_item.lake:
            raise ValueError("lake isn't set")
        if ailake_item.columns and ailake_item.ignore_columns:
            raise ValueError("columns and ignore_columns can't be set at the same time")
        return ailake_item

    def ailake_path(self):
        params = []
        if self.project:
            params.append(self.project)
        if self.lake:
            params.append(self.lake)
        if self.cluster:
            params.append(f"cluster={self.cluster}")
        if self.family:
            params.append(f"family={self.family}")
        if self.partition:
            params.append(f"partition={self.partition}")

        return f"ailake://{'/'.join(params)}"

    def format(self):
        params = {
            "buffer_size": self.buffer_size,
            "start": self.start,
            "end": self.end
        }
        if self.special_column_types is not None:
            params["special_column_types"] = ",".join(
                [f"{key}:{value}" for key, value in self.special_column_types.items()])
        if self.columns is not None:
            params["columns"] = ",".join(self.columns)
        if self.ignore_columns is not None:
            params["ignore_columns"] = ",".join(self.ignore_columns)

        table_path = self.ailake_path()
        param_str = "&".join([f"{key}={value}" for key, value in params.items() if value is not None])

        if param_str and len(param_str) > 0:
            return f"{table_path}?{param_str}"
        else:
            return table_path


class AilakeItemList(List[AilakeItem]):

    @staticmethod
    def parse(param_list):
        ailake_item_list: AilakeItemList = AilakeItemList()
        for param in param_list:
            ailake_item = AilakeItem.parse(param)
            ailake_item_list.append(ailake_item)
        return ailake_item_list

    def format(self):
        return [item.format() for item in self]


class AilakeItemDict(Dict[str, AilakeItemList]):
    @staticmethod
    def parse(param_dict):
        ailake_item_dict: AilakeItemDict = AilakeItemDict()
        for split_name, split_param_list in param_dict.items():
            ailake_item_dict[split_name] = AilakeItemList.parse(split_param_list)
        return ailake_item_dict

    def format(self):
        return {split_name: item_list.format() for split_name, item_list in self.items()}
