from dataclasses import dataclass
from typing import Optional, TYPE_CHECKING

import datasets
import datasets.config
import pyarrow as pa
from datasets.features.features import require_storage_cast
from datasets.table import table_cast

if TYPE_CHECKING:
    import mysql.connector

logger = datasets.utils.logging.get_logger(__name__)


@dataclass
class LogHouseConfig(datasets.BuilderConfig):
    """BuilderConfig for LogHouse."""

    sqls: dict = None
    app: str = None
    user: str = None
    password: str = None
    host: str = "loghouse-sql.alibaba.com"
    port: int = 9999

    features: Optional[datasets.Features] = None

    def __post_init__(self):
        if self.sqls is None:
            raise ValueError("sqls must be specified")
        if not isinstance(self.sqls, dict):
            self.sqls = {"train": self.sqls}
        if self.app is None:
            raise ValueError("app must be specified")
        if self.user is None:
            raise ValueError("user must be specified")
        if self.password is None:
            raise ValueError("password must be specified")
        if self.host is None:
            raise ValueError("host must be specified")
        if self.port is None:
            raise ValueError("port must be specified")

    def create_config_id(
            self,
            config_kwargs: dict,
            custom_features: Optional[datasets.Features] = None,
    ) -> str:
        config_kwargs = config_kwargs.copy()
        return super().create_config_id(config_kwargs, custom_features=custom_features)

    @property
    def connection_kwargs(self):
        kwargs = {
            'user': self.user,
            'password': self.password,
            'host': self.host,
            'database': self.app,
            'port': self.port
        }
        return kwargs


class LogHouse(datasets.ArrowBasedBuilder):
    BUILDER_CONFIG_CLASS = LogHouseConfig

    def _info(self):
        return datasets.DatasetInfo(features=self.config.features)

    def _split_generators(self, dl_manager):
        splits = []
        for split_name, sql in self.config.sqls.items():
            splits.append(datasets.SplitGenerator(name=split_name, gen_kwargs={"sql": sql}))
        return splits

    def _cast_table(self, pa_table: pa.Table) -> pa.Table:
        if self.config.features is not None:
            schema = self.config.features.arrow_schema
            if all(not require_storage_cast(feature) for feature in self.config.features.values()):
                # cheaper cast
                pa_table = pa.Table.from_arrays([pa_table[field.name] for field in schema], schema=schema)
            else:
                # more expensive cast; allows str <-> int/float or str to Audio for example
                pa_table = table_cast(pa_table, schema)
        return pa_table

    def _generate_tables(self, sql):
        import mysql.connector
        cnx = mysql.connector.connect(**self.config.connection_kwargs)

        cur = cnx.cursor()
        cur.execute(sql)
        names = [column[0] for column in cur.description]
        for idx, values in enumerate(cur.fetchall()):
            data = {name: value for name, value in zip(names, values)}
            pa_table = pa.Table.from_pylist([data])
            yield idx, self._cast_table(pa_table)
        cur.close()
        cnx.close()
