from typing import List, Dict, Optional, Union

import datasets
from datasets.utils.cypher_util import Cypher

logger = datasets.utils.logging.get_logger(__name__)


class OdpsItem:
    odps_project: str = None
    odps_table: str = None
    odps_partitions: str = None
    access_id: str = None
    access_key: str = None
    access_project = None
    end_point: str = None
    tunnel_end_point: str = None
    account_type: str = None
    direct_read: bool = None
    raw_tunnel: bool = None
    buffer_size: int = None
    num_threads: int = 1
    # TODO:mdl add for odps streaming failover
    # TODO:Later, need to provide a complete dataset failvoer solution
    skip_data_length: int = 0
    special_column_types: Optional[Union[str, Dict]] = None
    columns: Optional[Union[str,List[str]]] = None
    ignore_columns: Optional[Union[str,List[str]]] = None
    start: int = None
    end: int = None
    row_id_column: str = None
    _pre_processors: Dict = None

    @staticmethod
    def parse_special_column_types(special_column_types):
        if special_column_types is None:
            return None
        if isinstance(special_column_types, str):
            mapping = {}
            for kv in special_column_types.split(','):
                if '=' in kv:
                    tmp = kv.split('=')
                else:
                    tmp = kv.split(':')
                if len(tmp) != 2:
                    raise ValueError(f"invalid special_column_types={special_column_types}")
                mapping[tmp[0].strip()] = tmp[1].strip()
            return mapping
        elif isinstance(special_column_types, dict):
            return special_column_types
        else:
            raise ValueError(
                f"not supported type={type(special_column_types)} of special_column_types={special_column_types}")

    @staticmethod
    def parse_columns(columns):
        if columns is None:
            return None
        if isinstance(columns, str):
            return [column.strip() for column in columns.split(',')]
        elif isinstance(columns, (tuple, list)):
            return columns
        else:
            raise ValueError(
                f"not supported type={type(columns)} of columns={columns}")

    @staticmethod
    def parse(param, decrypt=False):
        odps_item = OdpsItem()

        if isinstance(param, dict):
            odps_item.odps_project = param.get("odps_project", None)
            odps_item.odps_table = param.get("odps_table", None)
            odps_item.odps_partitions = param.get("odps_partitions", None)
            odps_item.access_id = param.get("access_id", None)
            odps_item.access_key = param.get("access_key", None)
            odps_item.access_project = param.get("access_project", None)
            odps_item.end_point = param.get("end_point", None)
            odps_item.tunnel_end_point = param.get("tunnel_end_point", None)
            odps_item.account_type = param.get("account_type", None)
            odps_item.direct_read = str(param["direct_read"]).lower() == "true" if "direct_read" in param else None
            odps_item.raw_tunnel = str(param["raw_tunnel"]).lower() == "true" if "raw_tunnel" in param else None
            odps_item.buffer_size = param.get("buffer_size", None)
            if odps_item.buffer_size is not None:
                odps_item.buffer_size = int(odps_item.buffer_size)
            odps_item.num_threads = param.get("num_threads", None)
            if odps_item.num_threads is not None:
                odps_item.num_threads = int(odps_item.num_threads)
            odps_item.special_column_types = OdpsItem.parse_special_column_types(
                param.get("special_column_types", None))
            odps_item.start = param.get("start", None)
            odps_item.end = param.get("end", None)
            odps_item.row_id_column = param.get("row_id_column", None)
            odps_item.columns = OdpsItem.parse_columns(param.get("columns", None))
            odps_item.ignore_columns = OdpsItem.parse_columns(param.get("ignore_columns", None))
        elif isinstance(param, str):
            pos = param.find('?')
            prefix = param if pos < 0 else param[:pos]

            str_list = prefix.split("/")
            if len(str_list) < 5 or str_list[3] != "tables":
                raise ValueError(
                    "'%s' is invalid, please refer: 'odps://${project_name}/"
                    "tables/${table_name}/${pt_1}/${pt_2}/...'" % prefix)

            odps_item.odps_project = str_list[2]
            odps_item.odps_table = str_list[4]
            if len(str_list) > 5:
                odps_item.odps_partitions = "/".join(str_list[5:])

            from urllib.parse import parse_qs, urlparse
            parsed_url = urlparse(param)
            url_params = parse_qs(parsed_url.query)

            for key, value in url_params.items():
                if len(value) > 1:
                    raise ValueError("multiple value is set for parameter: {}={}".format(key, value))
                value = value[0]
                if value is None:
                    continue
                if key == "access_id":
                    odps_item.access_id = value
                elif key == "access_key":
                    odps_item.access_key = value
                elif key == "access_project":
                    odps_item.access_project = value
                elif key == "end_point":
                    odps_item.end_point = value
                elif key == "tunnel_end_point":
                    odps_item.tunnel_end_point = value
                elif key == "account_type":
                    odps_item.account_type = value
                elif key == "direct_read":
                    odps_item.direct_read = str(value).lower() == "true"
                elif key == "raw_tunnel":
                    odps_item.raw_tunnel = str(value).lower() == "true"
                elif key == "buffer_size":
                    odps_item.buffer_size = int(value)
                elif key == "num_threads":
                    odps_item.num_threads = int(value)
                elif key == "skip_data_length":
                    odps_item.skip_data_length = int(value)
                elif key == "special_column_types":
                    odps_item.special_column_types = OdpsItem.parse_special_column_types(value)
                elif key == "columns":
                    odps_item.columns = OdpsItem.parse_columns(value)
                elif key == "ignore_columns":
                    odps_item.ignore_columns = OdpsItem.parse_columns(value)
                elif key == "start":
                    odps_item.start = int(value)
                elif key == "end":
                    odps_item.end = int(value)
                elif key == "row_id_column":
                    odps_item.row_id_column = value
                else:
                    logger.warning("skip unknown parameter: {}={}".format(key, value))
        else:
            raise ValueError(f"parse odps item failed, unknown type {type(param)}, params={param}")

        if decrypt and odps_item.access_id is not None:
            odps_item.access_id = Cypher.decrypt(odps_item.access_id)
        if decrypt and odps_item.access_key is not None:
            odps_item.access_key = Cypher.decrypt(odps_item.access_key)
        if odps_item.columns and odps_item.ignore_columns:
            raise ValueError("columns and ignore_columns can't be set at the same time")
        return odps_item

    def table_path(self):
        if self.odps_partitions is None or len(self.odps_partitions) <= 0:
            _table_path = "odps://{}/tables/{}".format(self.odps_project, self.odps_table)
        else:
            _table_path = "odps://{}/tables/{}/{}".format(self.odps_project, self.odps_table,
                                                          self.odps_partitions.replace(',', '/'))
        return _table_path

    def format(self, hidden=False):
        params = {
            "access_id": Cypher.hidden(self.access_id) if hidden else self.access_id,
            "access_key": Cypher.hidden(self.access_key) if hidden else self.access_key,
            "access_project": self.access_project,
            "end_point": self.end_point,
            "tunnel_end_point": self.tunnel_end_point,
            "account_type": self.account_type,
            "direct_read": self.direct_read,
            "raw_tunnel": self.raw_tunnel,
            "buffer_size": self.buffer_size,
            "num_threads": self.num_threads if self.direct_read else None,
            "start": self.start,
            "end": self.end,
            "row_id_column": self.row_id_column,
        }
        if self.special_column_types is not None:
            params["special_column_types"] = ",".join(
                [f"{key}:{value}" for key, value in self.special_column_types.items()])
        if self.columns is not None:
            params["columns"] = ",".join(self.columns)
        if self.ignore_columns is not None:
            params["ignore_columns"] = ",".join(self.ignore_columns)

        table_path = self.table_path()
        param_str = "&".join([f"{key}={value}" for key, value in params.items() if value is not None])

        if param_str and len(param_str) > 0:
            return f"{table_path}?{param_str}"
        else:
            return table_path


class OdpsItemList(List[OdpsItem]):

    @staticmethod
    def parse(param_list, decrypt=False):
        odps_item_list: OdpsItemList = OdpsItemList()
        for param in param_list:
            odps_item = OdpsItem.parse(param, decrypt=decrypt)
            odps_item_list.append(odps_item)
        return odps_item_list

    def format(self):
        return [item.format() for item in self]


class OdpsItemDict(Dict[str, OdpsItemList]):
    @staticmethod
    def parse(param_dict, decrypt=False):
        odps_item_dict: OdpsItemDict = OdpsItemDict()
        for split_name, split_param_list in param_dict.items():
            odps_item_dict[split_name] = OdpsItemList.parse(split_param_list, decrypt=decrypt)
        return odps_item_dict

    def format(self):
        return {split_name: item_list.format() for split_name, item_list in self.items()}
