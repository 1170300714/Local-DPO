import base64
import json
import os
from urllib.parse import urlencode, urlparse

from datasets.utils.logging import get_logger
from datasets.utils.multimedia_util import check_media_type
from .oss_util import load_oss_file, fetch_aidata_oss_info, load_aidata_oss_file, map_oss_path, \
    check_oss_mount_mappings
from .ailake_table_util import read_lookup_table, close_lookup_table_reader

logger = get_logger(__name__)


class DecodeBase64Processor:
    def __init__(self, **kwargs):
        pass

    def __call__(self, value: str):
        return base64.b64decode(value)


class DecodeJsonProcessor:
    def __init__(self, **kwargs):
        pass

    def __call__(self, value: str):
        return json.loads(value)


class RefProcessor:
    def __init__(self, **kwargs):
        self.lazy_load = str(kwargs.get('lazy_load', False)).lower() == 'true'
        self.oss_mount_mappings = kwargs.get('oss_mount_mappings', None)
        self.oss_access_key_id = kwargs.get('oss_access_key_id', None)
        self.oss_access_key_secret = kwargs.get('oss_access_key_secret', None)
        self.oss_security_token = kwargs.get('oss_security_token', None)
        self.oss_endpoint = kwargs.get('oss_endpoint', None)
        self.ailake_admin_address = kwargs.get('ailake_admin_address', None)
        self.log_metric_interval = int(kwargs.get('log_metric_interval', 10000))
        self.path_formatter = kwargs.get('path_formatter', None)
        self.path_seperator = kwargs.get('path_seperator', None)
        self.ignore_not_exist = str(kwargs.get('ignore_not_exist', False)).lower() == 'true'
        self.ignore_read_fail = str(kwargs.get('ignore_read_fail', False)).lower() == 'true'
        self.ignore_decode_fail = str(kwargs.get('ignore_decode_fail', False)).lower() == 'true'
        self.print_ignore_log = str(kwargs.get('print_ignore_log', True)).lower() == 'true'
        self.multiple = kwargs.get('multiple', False)
        self.media_type = kwargs['media_type']
        check_media_type(self.media_type)

        if self.oss_mount_mappings:
            if self.ailake_admin_address:
                raise ValueError("oss_mount and ailake can't be set at the same time")
            self.mode = "oss_mount"
            check_oss_mount_mappings(self.oss_mount_mappings)
        elif self.ailake_admin_address:
            if self.oss_mount_mappings:
                raise ValueError("oss_mount and ailake can't be set at the same time")
            self.mode = "ailake"
        else:
            self.mode = ""

    def is_lazy_load(self):
        return self.lazy_load

    def close(self):
        if self.mode == "ailake":
            close_lookup_table_reader(self.ailake_admin_address)

    def __call__(self, path: str):
        if path is None:
            paths = []
        elif isinstance(path, (tuple, list)):
            paths = path
        else:
            if self.path_seperator:
                paths = path.split(self.path_seperator)
            else:
                paths = [path]

        results = []
        for path in paths:
            if not path:
                results.append(None)
                continue

            if self.path_formatter:
                path = self.path_formatter.format(path)

            if self.mode == "oss_mount":
                if self.lazy_load:
                    results.append({
                        "path": path,
                        "bytes": None
                    })
                else:
                    with open(path, "rb") as f:
                        results.append({
                            "bytes": f.read(),
                            "path": path
                        })
            elif self.mode == "ailake":
                if self.lazy_load:
                    params = {
                        "ailake_admin_address": self.ailake_admin_address,
                        "log_metric_interval": self.log_metric_interval,
                        "media_type": self.media_type,
                        "ignore_not_exist": self.ignore_not_exist,
                        "ignore_decode_fail": self.ignore_decode_fail,
                        "ignore_read_fail": self.ignore_read_fail,
                        "print_ignore_log": self.print_ignore_log,
                    }
                    results.append({
                        "path": f"ailake://{path}?{urlencode(params)}",
                        "bytes": None
                    })
                else:
                    results.append(read_lookup_table(path,
                                                     media_type=self.media_type,
                                                     ailake_admin_address=self.ailake_admin_address,
                                                     log_metric_interval=self.log_metric_interval,
                                                     ignore_not_exist=self.ignore_not_exist,
                                                     ignore_decode_fail=self.ignore_decode_fail,
                                                     ignore_read_fail=self.ignore_read_fail,
                                                     print_ignore_log=self.print_ignore_log
                                                     ))
            else:
                if self.lazy_load:
                    params = {
                        "media_type": self.media_type,
                        "oss_access_key_id": self.oss_access_key_id or "",
                        "oss_access_key_secret": self.oss_access_key_secret or "",
                        "oss_security_token": self.oss_security_token or "",
                        "oss_endpoint": self.oss_endpoint or "",
                        "ignore_not_exist": self.ignore_not_exist,
                        "ignore_decode_fail": self.ignore_decode_fail,
                        "ignore_read_fail": self.ignore_read_fail,
                        "print_ignore_log": self.print_ignore_log,
                    }
                    results.append({
                        # "path": f"{path}?{'&'.join([k + '=' + v for k, v in params.items() if v is not None])}",
                        "path": f"{path}?{urlencode(params)}",
                        "bytes": None
                    })
                else:
                    results.append(load_oss_file(path,
                                                 media_type=self.media_type,
                                                 oss_access_key_id=self.oss_access_key_id,
                                                 oss_access_key_secret=self.oss_access_key_secret,
                                                 oss_endpoint=self.oss_endpoint,
                                                 oss_security_token=self.oss_security_token,
                                                 ignore_not_exist=self.ignore_not_exist,
                                                 ignore_decode_fail=self.ignore_decode_fail,
                                                 ignore_read_fail=self.ignore_read_fail,
                                                 print_ignore_log=self.print_ignore_log))
        return results if self.multiple else results[0]


class AiDataRefProcessor:
    def __init__(self, **kwargs):
        self.app_key = kwargs.get('aidata_app_key', None)
        if self.app_key is None:
            raise ValueError("missing 'aidata_app_key' parameter in 'extras'")
        self.lazy_load = str(kwargs.get('lazy_load', False)).lower() == 'true'
        self.oss_mount_mappings = kwargs.get('oss_mount_mappings', None)
        if self.oss_mount_mappings:
            check_oss_mount_mappings(self.oss_mount_mappings)
        self.scene = kwargs.get('aidata_scene', None)
        if self.scene is None:
            raise ValueError("missing 'aidata_scene' parameter in 'extras'")
        self.multiple = kwargs.get('multiple', False)
        self.oss_info = None

    def is_lazy_load(self):
        return self.lazy_load

    def get_oss_info(self, file_path, refresh=False):
        if self.oss_info is None or refresh:
            self.oss_info = fetch_aidata_oss_info(self.app_key, self.scene, urlparse(file_path).netloc)
        return self.oss_info

    def __call__(self, path: str):
        paths = path if self.multiple else [path]
        if paths is None:
            paths = []
        results = []
        for path in paths:
            if not path:
                results.append(None)
                continue
            if self.oss_mount_mappings:
                path = map_oss_path(path, self.oss_mount_mappings)
                if self.lazy_load:
                    results.append({
                        "path": path,
                        "bytes": None
                    })
                else:
                    with open(path, "rb") as f:
                        results.append({
                            "bytes": f.read(),
                            "path": path
                        })
            else:
                if self.lazy_load:
                    pos = path.find("://")
                    if pos == -1:
                        oss_info = self.get_oss_info(path)
                        bucket_name = oss_info["bucketName"]
                        path = os.path.join(f"oss://{bucket_name}/", path)
                    results.append({
                        "path": f"{path}?aidata_app_key={self.app_key}&aidata_scene={self.scene}",
                        "bytes": None
                    })
                else:
                    oss_info = self.get_oss_info(path)
                    results.append(load_aidata_oss_file(file_path=path,
                                                        aidata_app_key=self.app_key,
                                                        aidata_scene=self.scene,
                                                        oss_info=oss_info))
        return results if self.multiple else results[0]
