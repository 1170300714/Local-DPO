import copy
from dataclasses import dataclass
from typing import Optional, Union, Dict
import time
import pyarrow as pa

import datasets
import datasets.config
from datasets.features.features import require_storage_cast
from datasets.iterable_dataset import ExamplesIterable
from datasets.table import table_cast
from .odps_iterable import OdpsExamplesIterable
from .odps_items import OdpsItem, OdpsItemList, OdpsItemDict

logger = datasets.utils.logging.get_logger(__name__)


@dataclass
class OdpsConfig(datasets.BuilderConfig):
    """BuilderConfig for Odps."""
    odps_item_dict: OdpsItemDict = None
    account_type: Optional[str] = None
    access_id: Optional[str] = None
    access_key: Optional[str] = None
    access_project: Optional[str] = None
    end_point: Optional[str] = "http://service-corp.odps.aliyun-inc.com/api"
    tunnel_end_point: Optional[str] = None
    direct_read: bool = None
    raw_tunnel: bool = None
    buffer_size: int = None
    num_workers: int = None
    world_size: int = None
    rank: int = None
    drop_left: bool = False
    features: Optional[datasets.Features] = None
    token: Optional[str] = None
    extras: Optional[Dict] = None

    def __post_init__(self):
        if self.account_type:
            if self.access_id:
                raise ValueError("account_type and access_id should not be set at the same time")
            if self.access_key:
                raise ValueError("account_type and access_key should not be set at the same time")

            from .odps_util import get_odps_account
            self.access_id, self.access_key, self.end_point = get_odps_account(self.account_type, token=self.token)

        pre_file = None
        pre_columns = None
        columns_cache = {}
        self.odps_item_dict = OdpsItemDict()
        for split_name, split_data_files in self.data_files.items():
            if isinstance(split_data_files, str):
                split_data_files = [split_data_files]

            split_odps_item_list: OdpsItemList = OdpsItemList()

            for data_file in split_data_files:
                odps_item: OdpsItem = OdpsItem.parse(data_file)

                if odps_item.account_type:
                    if odps_item.access_id:
                        raise ValueError("account_type and access_id should not be set at the same time")
                    if odps_item.access_key:
                        raise ValueError("account_type and access_key should not be set at the same time")

                    from .odps_util import get_odps_account
                    odps_item.access_id, odps_item.access_key, odps_item.end_point = get_odps_account(
                        odps_item.account_type, token=self.token)

                if odps_item.access_id is None:
                    odps_item.access_id = self.access_id
                if odps_item.access_key is None:
                    odps_item.access_key = self.access_key
                if odps_item.access_project is None:
                    odps_item.access_project = self.access_project
                if odps_item.end_point is None:
                    odps_item.end_point = self.end_point
                if odps_item.tunnel_end_point is None:
                    odps_item.tunnel_end_point = self.tunnel_end_point
                if odps_item.direct_read is None:
                    odps_item.direct_read = self.direct_read
                if odps_item.raw_tunnel is None:
                    odps_item.raw_tunnel = self.raw_tunnel
                if odps_item.direct_read is None:
                    odps_item.direct_read = odps_item.access_id is None and odps_item.access_key is None
                if self.buffer_size:
                    odps_item.buffer_size = self.buffer_size

                logger.warning("split: %s, odps_item: %s", split_name, odps_item.format(hidden=True))

                columns_cache_key = f"{odps_item.odps_project}.{odps_item.odps_table}"
                if columns_cache_key in columns_cache:
                    columns = copy.deepcopy(columns_cache[columns_cache_key])
                else:
                    if odps_item.direct_read:
                        from .odps_util import get_table_meta_by_direct
                        columns, _ = get_table_meta_by_direct(odps_item.table_path(), inference_array_column=True)
                    elif odps_item.raw_tunnel:
                        from .odps_util import get_table_meta_by_raw_tunnel
                        columns, _ = get_table_meta_by_raw_tunnel(odps_item=odps_item, return_row_count=False)
                    else:
                        from .odps_util import get_table_meta_by_tunnel
                        columns, _ = get_table_meta_by_tunnel(odps_item=odps_item, return_row_count=False)
                    columns_cache[columns_cache_key] = copy.deepcopy(columns)

                from .odps_util import merge_columns_with_special_column_types
                if odps_item.columns:
                    for column in odps_item.columns:
                        if column not in columns:
                            raise ValueError(f"column {column} not in {odps_item.table_path()}, all columns={columns}")
                    columns = { key: value for key, value in columns.items() if key in odps_item.columns }
                elif odps_item.ignore_columns:
                    for ignore_column in odps_item.ignore_columns:
                        if ignore_column not in columns:
                            raise ValueError(
                                f"ignore_column {ignore_column} not in {odps_item.table_path()}, all columns={columns}")
                    columns = {key: value for key, value in columns.items() if key not in odps_item.ignore_columns}
                if odps_item.row_id_column:
                    if odps_item.row_id_column in columns:
                        raise ValueError(f"row_id_column is set as {odps_item.row_id_column}, but this column is already exists in table schema")
                    columns[odps_item.row_id_column] = "BIGINT"
                columns, pre_processors = merge_columns_with_special_column_types(columns,
                                                                                  odps_item.special_column_types,
                                                                                  self.extras)
                odps_item._pre_processors = pre_processors

                if pre_columns and pre_columns != columns:
                    raise ValueError("mismatch schema, path1={}, schema1={}, path2={}, schema2={}".format(
                        pre_file, pre_columns, data_file, columns))
                else:
                    pre_file = data_file
                    pre_columns = columns

                split_odps_item_list.append(odps_item)

            self.odps_item_dict[split_name] = OdpsItemList(
                sorted(split_odps_item_list, key=lambda x: (x.odps_project, x.odps_table, x.odps_partitions)))

        if self.features is None:
            from .odps_util import odps_type_to_feature_type,get_multimedia_types
            self.features = datasets.Features({column_name: odps_type_to_feature_type(column_type)
                                               for column_name, column_type in pre_columns.items()})

            types = get_multimedia_types(self.features.to_dict())
            default_buffer_size = 10000
            if "Video" in types:
                default_buffer_size = 10
            elif "Audio" in types:
                default_buffer_size = 50
            elif "Image" in types or "Binary" in types:
                default_buffer_size = 100
            for split_name, split_odps_items in self.odps_item_dict.items():
                for odps_item in split_odps_items:
                    if odps_item.buffer_size is None:
                        odps_item.buffer_size = default_buffer_size

    def create_config_id(
            self,
            config_kwargs: dict,
            custom_features: Optional[datasets.Features] = None,
    ) -> str:
        config_kwargs = config_kwargs.copy()
        # We need to stringify the Selectable object to make its hash deterministic
        if "account_type" in config_kwargs:
            config_kwargs.pop("account_type")
        if "access_id" in config_kwargs:
            config_kwargs.pop("access_id")
        if "access_key" in config_kwargs:
            config_kwargs.pop("access_key")
        if "access_project" in config_kwargs:
            config_kwargs.pop("access_project")
        if "end_point" in config_kwargs:
            config_kwargs.pop("end_point")
        if "tunnel_end_point" in config_kwargs:
            config_kwargs.pop("tunnel_end_point")
        if "direct_read" in config_kwargs:
            config_kwargs.pop("direct_read")
        if "raw_tunnel" in config_kwargs:
            config_kwargs.pop("raw_tunnel")
        if "token" in config_kwargs:
            config_kwargs.pop("token")
        config_kwargs["odps_items"] = self.odps_item_dict.format()

        return super().create_config_id(config_kwargs, custom_features=custom_features)


class Odps(datasets.ArrowBasedBuilder):
    BUILDER_CONFIG_CLASS = OdpsConfig

    def _info(self):
        return datasets.DatasetInfo(features=self.config.features)

    def _split_generators(self, dl_manager):
        splits = []
        split_infos = datasets.SplitDict()
        for split_name, split_odps_items in self.config.odps_item_dict.items():
            split_shards = []
            split_odps_columns = []
            split_buffer_sizes = []
            split_row_count = 0

            def shard_odps_item(odps_item):
                start = time.time()
                if odps_item.direct_read:
                    from .odps_util import get_table_meta_by_direct
                    columns, row_count = get_table_meta_by_direct(odps_item.table_path(), inference_array_column=False)
                elif odps_item.raw_tunnel:
                    from .odps_util import get_table_meta_by_raw_tunnel
                    columns, row_count = get_table_meta_by_raw_tunnel(odps_item, return_row_count=True)
                else:
                    from .odps_util import get_table_meta_by_tunnel
                    columns, row_count = get_table_meta_by_tunnel(odps_item, return_row_count=True)

                buffer_size = odps_item.buffer_size
                if buffer_size is None or buffer_size <= 0:
                    buffer_size = min(10000, max(int(row_count / 10), 100))

                from .odps_util import shard_rows, row_count_of_shards
                shards = shard_rows(odps_item.table_path(), row_count,
                                    start=odps_item.start,
                                    end=odps_item.end,
                                    num_workers=self.config.num_workers,
                                    world_size=self.config.world_size,
                                    rank=self.config.rank,
                                    drop_left=self.config.drop_left,
                                    num_proc=dl_manager.download_config.num_proc)
                if odps_item.skip_data_length > 0:
                    from .odps_util import skip_data_for_sharding
                    shards = skip_data_for_sharding(shards, odps_item.skip_data_length)

                if odps_item.columns:
                    columns = { key: value for key, value in columns.items() if key in odps_item.columns }
                elif odps_item.ignore_columns:
                    columns = {key: value for key, value in columns.items() if key not in odps_item.ignore_columns}

                logger.warning(
                    "split: %s, table_path: %s, direct_read: %s, raw_tunnel: %s, rows: %s, columns: %s, "
                    "buffer_size: %s, num_shards: %s, actual_rows(rows of shards): %s, time_elapsed: %ss",
                    split_name, odps_item.table_path(), odps_item.direct_read, odps_item.raw_tunnel,
                    row_count, columns, buffer_size, len(shards), row_count_of_shards(shards), int(time.time() - start))

                return shards, columns, buffer_size, row_count_of_shards(shards)

            dones = []
            from concurrent.futures import ThreadPoolExecutor
            thread_count = min(20, max(1, len(split_odps_items) // 2))
            pool = ThreadPoolExecutor(max_workers=thread_count)
            for item_idx, odps_item in enumerate(split_odps_items):
                dones.append(pool.submit(shard_odps_item, odps_item))

            for item_idx, done in enumerate(dones):
                shards, columns, buffer_size, row_count = done.result()
                split_shards.extend([(item_idx, shard_idx, *shard, 0) for shard_idx, shard in enumerate(shards)])
                split_odps_columns.append(columns)
                split_buffer_sizes.append(buffer_size)
                split_row_count += row_count
            pool.shutdown()

            splits.append(
                datasets.SplitGenerator(name=split_name, gen_kwargs={
                    "odps_items": tuple(split_odps_items),
                    "odps_columns": tuple(split_odps_columns),
                    "buffer_sizes": tuple(split_buffer_sizes),
                    "shards": split_shards}))
            split_infos[split_name] = datasets.SplitInfo(name=split_name, num_examples=split_row_count)
        self.info.splits = split_infos
        self.cheap_cast = all(not require_storage_cast(feature) for feature in self.config.features.values())
        return splits

    def _cast_table(self, pa_table: pa.Table) -> pa.Table:
        if self.config.features is not None:
            schema = self.config.features.arrow_schema
            if self.cheap_cast:
                # cheaper cast
                pa_table = pa.Table.from_arrays([pa_table[field.name] for field in schema], schema=schema)
            else:
                # more expensive cast; allows str <-> int/float or str to Audio for example
                pa_table = table_cast(pa_table, schema)
        return pa_table

    def _generate_tables(self, odps_items, odps_columns, buffer_sizes, shards):
        row_count = 0
        cur_row_count = 0
        for item_idx, shard_idx, start, stop, offset in shards:
            row_count += stop - start
            cur_row_count += offset
        log_time_interval = 300
        last_log_time = -1
        log_row_interval = max(1, min(int(row_count / 10), 10000))
        last_log_row_step = -1
        from .odps_util import get_process_name
        process_name = get_process_name()

        logger.warning("%s - begin to read, num_shards: %s, rows: %s/%s, shards: %s",
                       process_name, len(shards), cur_row_count, row_count, shards)

        for idx, shard in enumerate(shards):
            item_idx, shard_idx, start, stop, offset = shard
            start += offset
            if start >= stop:
                logger.warning("%s - skip empty shard: %s", process_name, shard)
                continue
            odps_item = odps_items[item_idx]
            columns = odps_columns[item_idx]
            buffer_size = buffer_sizes[item_idx]
            if odps_item.direct_read:
                from common_io.exception import OutOfRangeException
                from common_io.table import TableReader
                _table_path = odps_item.table_path()
                table_path = "{}?start={}&end={}".format(_table_path, start, stop)
                reader = TableReader(
                    table_path, selected_cols=",".join(columns.keys()), num_threads=odps_item.num_threads,
                    capacity=buffer_size
                )
                retries = 0
                max_retries = 5
                retry_sleep_time = 3
                row_idx = start
                while True:
                    try:
                        records = reader.read(num_records=buffer_size, allow_smaller_final_batch=True)
                        retries = 0
                    except OutOfRangeException:
                        try:
                            reader.close()
                        except Exception as ce:
                            import traceback
                            logger.warning("%s - close read failed, ignore, error: %s | %s",
                                           process_name, ce, traceback.format_exc())
                        break
                    except Exception as e:
                        retries += 1
                        if retries < max_retries:
                            import traceback
                            logger.warning("%s - read row failed, %s retries left, error: %s | %s",
                                           process_name, max_retries - retries, e, traceback.format_exc())
                            time.sleep(retry_sleep_time)
                            continue
                        else:
                            raise e

                    cur_row_count += len(records)
                    cur_time = time.time()
                    if cur_row_count // log_row_interval != last_log_row_step or (cur_time - last_log_time) > log_time_interval:
                        logger.warning("%s - table_path: %s, shards: %s/%s, rows: %s/%s, progress: %.1f%%",
                                       process_name, odps_item.table_path(), idx + 1, len(shards), cur_row_count,
                                       row_count, 100 * cur_row_count / row_count)
                        last_log_row_step = cur_row_count // log_row_interval
                        last_log_time = cur_time

                    datas = []
                    for i in range(len(records)):
                        record = records[i]
                        data = {key: value.decode() if isinstance(value, bytes) else value for key, value in
                                zip(columns, record)}
                        if odps_item.row_id_column:
                            data[odps_item.row_id_column] = row_idx
                        data = self._process(odps_item._pre_processors, data)
                        datas.append(data)
                        row_idx += 1
                    pa_table = pa.Table.from_pylist(datas)
                    yield (item_idx, row_idx), self._cast_table(pa_table)
            elif odps_item.raw_tunnel:
                from .odps_util import create_download_session, create_download_session_reader
                from odps.errors import NoPermission

                download_session = create_download_session(odps_item)
                download_session_reader = create_download_session_reader(download_session, start=start, count=stop - start,
                                                              columns=list(columns.keys()))
                retries = 0
                max_retries = 10
                retry_sleep_time = 3
                row_idx = start
                while start < stop:
                    try:
                        records = [download_session_reader.read() for _ in range(min((stop - start), buffer_size))]
                        retries = 0
                    except Exception as e:
                        retries += 1
                        if retries < max_retries:
                            import traceback
                            logger.warning("%s - read row failed, %s retries left, error: %s | %s",
                                           process_name, max_retries - retries, e, traceback.format_exc())
                            time.sleep(retry_sleep_time)
                            try:
                                download_session_reader.close()
                            except:
                                pass
                            download_session = create_download_session(odps_item)
                            download_session_reader = create_download_session_reader(download_session, start=start,
                                                                          count=stop - start,
                                                                          columns=list(columns.keys()))
                            logger.warning("%s - recreate download session reader success", process_name)
                            continue
                        else:
                            raise e

                    cur_row_count += len(records)
                    if cur_row_count // log_row_interval != last_log_row_step:
                        logger.warning("%s - table_path: %s, shards: %s/%s, rows: %s/%s, progress: %.1f%%",
                                       process_name, odps_item.table_path(), idx + 1, len(shards),
                                       cur_row_count, row_count, 100 * cur_row_count / row_count)
                        last_log_row_step = cur_row_count // log_row_interval

                    datas = []
                    for record in records:
                        data = {}
                        for field in record:
                            if field[0] not in columns:
                                continue
                            data[field[0]] = field[1]
                        if odps_item.row_id_column:
                            data[odps_item.row_id_column] = row_idx
                        data = self._process(odps_item._pre_processors, data)
                        datas.append(data)
                        row_idx += 1
                    pa_table = pa.Table.from_pylist(datas)
                    yield (item_idx, row_idx), self._cast_table(pa_table)
                    start += len(records)
            else:
                from .odps_util import create_table_reader, get_table
                from odps.errors import NoPermission
                table = get_table(odps_project=odps_item.odps_project,
                                  odps_table=odps_item.odps_table,
                                  access_id=odps_item.access_id,
                                  access_key=odps_item.access_key,
                                  access_project=odps_item.access_project,
                                  end_point=odps_item.end_point,
                                  wait=False)
                if table is None:
                    raise ValueError(
                        "table isn't exists, odps_project={}, odps_table={}".format(odps_item.odps_project,
                                                                                    odps_item.odps_table))

                table_reader = create_table_reader(table=table, partition=odps_item.odps_partitions, columns=list(columns.keys()))

                retries = 0
                max_retries = 10
                retry_sleep_time = 3
                row_idx = start
                while start < stop:
                    try:
                        records = [record for record in
                                   table_reader.read(start=start, count=min((stop - start), buffer_size))]
                        retries = 0
                    except Exception as e:
                        retries += 1
                        if retries < max_retries and not isinstance(e, (NoPermission,)):
                            import traceback
                            logger.warning("%s - read row failed, %s retries left, error: %s | %s",
                                           process_name, max_retries - retries, e, traceback.format_exc())
                            time.sleep(retry_sleep_time)
                            table_reader = create_table_reader(table=table, partition=odps_item.odps_partitions, columns=list(columns.keys()))
                            logger.warning("%s - recreate table reader success", process_name)
                            continue
                        else:
                            raise e

                    cur_row_count += len(records)
                    if cur_row_count // log_row_interval != last_log_row_step:
                        logger.warning("%s - table_path: %s, shards: %s/%s, rows: %s/%s, progress: %.1f%%",
                                       process_name, odps_item.table_path(), idx + 1, len(shards),
                                       cur_row_count, row_count, 100 * cur_row_count / row_count)
                        last_log_row_step = cur_row_count // log_row_interval

                    datas = []
                    for record in records:
                        data = {}
                        for field in record:
                            if field[0] not in columns:
                                continue
                            data[field[0]] = field[1]
                        if odps_item.row_id_column:
                            data[odps_item.row_id_column] = row_idx
                        data = self._process(odps_item._pre_processors, data)
                        datas.append(data)
                        row_idx += 1
                    pa_table = pa.Table.from_pylist(datas)
                    yield (item_idx, row_idx), self._cast_table(pa_table)
                    start += len(records)

        for odps_item in odps_items:
            pre_processors = odps_item._pre_processors
            if pre_processors is not None and len(pre_processors) > 0:
                for name, pre_processor in pre_processors.items():
                    if hasattr(pre_processor, 'close'):
                        try:
                            pre_processor.close()
                        except Exception as e:
                            import traceback
                            logger.warning("%s - close pre_processor %s failed, ignore, error: %s | %s",
                                           process_name, name, e, traceback.format_exc())
        logger.warning("%s - end to read, num_shards: %s, rows: %s/%s, shards: %s",
                       process_name, len(shards), cur_row_count, row_count, shards)


    def _process(self, pre_processors, data):
        if pre_processors is not None and len(pre_processors) > 0:
            for name, pre_processor in pre_processors.items():
                if name in data:
                    value = pre_processor(data[name])
                    data[name] = value
        return self._process_example(data)

    # can be override by user
    def _process_example(self, data):
        return data

    def _get_examples_iterable_for_split(self, split_generator: "datasets.SplitGenerator") -> ExamplesIterable:
        return OdpsExamplesIterable(self._generate_tables, kwargs=split_generator.gen_kwargs)