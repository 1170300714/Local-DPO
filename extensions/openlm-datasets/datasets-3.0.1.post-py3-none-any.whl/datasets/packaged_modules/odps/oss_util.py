import copy
import json
import os
import time
from urllib.parse import urlparse

import datasets
import urllib3
from datasets.utils.cypher_util import Cypher
from datasets.utils.openlm_config import OpenlmConfig

logger = datasets.utils.logging.get_logger(__name__)

from datasets.utils.multimedia_util import decode_example


def check_oss_mount_mappings(oss_mount_mappings):
    for key,value in oss_mount_mappings.items():
        if not key.startswith('oss://'):
            raise ValueError(f"invalid key {key} in oss_mount_mappings {oss_mount_mappings}")
        if value.startswith('oss://'):
            raise ValueError(f"invalid value {value} in oss_mount_mappings {oss_mount_mappings}")


def map_oss_path(path, oss_mount_mappings):
    found = False
    for key, value in oss_mount_mappings.items():
        if path.startswith(key):
            path = path[len(key):]
            path = os.path.join(value, path.lstrip('/'))
            found = True
            break
    if not found:
        raise ValueError(f"no oss mount mapping is found in {oss_mount_mappings} for path {path}")
    return path


def create_aidata_oss_bucket(oss_info):
    import oss2
    auth = oss2.StsAuth(oss_info["accessKeyId"], oss_info["accessKeySecret"], oss_info["securityToken"])
    bucket = oss2.Bucket(auth, oss_info["endpoint"], oss_info["bucketName"])
    return bucket


def fetch_aidata_oss_info(app_key, scene, bucket):
    url = "https://{}dataai.alibaba-inc.com/api/v1/corpora/token?appKey={}&scene={}&bucket={}".format(
        "pre-" if OpenlmConfig.get_env() == "pre" else "", app_key, scene, bucket)
    sleep_time = 30
    retries = 3

    while True:
        response = None
        response_json = None
        try:
            timeout = urllib3.Timeout(connect=60.0, read=60.0)
            http = urllib3.PoolManager(timeout=timeout, cert_reqs='CERT_NONE')
            urllib3.disable_warnings()
            response = http.request('GET', url).data.decode('utf-8')
            response_json = json.loads(response)

            if "success" not in response_json or not response_json["success"]:
                raise IOError(f"response isn't success, error message: {response_json.get('message', '')}")
            data = response_json["data"]
            hidden_data = copy.deepcopy(data)
            hidden_data["accessKeySecret"] = Cypher.hidden(hidden_data["accessKeySecret"])
            hidden_data["accessKeyId"] = Cypher.hidden(hidden_data["accessKeyId"])
            hidden_data["securityToken"] = Cypher.hidden(hidden_data["securityToken"])
            logger.info("get aidata oss info success, response=%s", json.dumps(hidden_data, indent=2))
            return data
        except Exception as e:
            retries -= 1
            if retries > 0:
                logger.warning("get aidata oss info failed, %s retries left, response=%s, exception=%s", retries,
                               json.dumps(response_json, indent=2) if response_json else response, str(e))
                time.sleep(sleep_time)
            else:
                logger.error("get aidata oss info failed, response=%s, exception=%s",
                             json.dumps(response_json, indent=2) if response_json else response, str(e))
                raise e


def load_aidata_oss_file(file_path, aidata_app_key, aidata_scene, oss_info=None):
    if not oss_info:
        oss_info = fetch_aidata_oss_info(aidata_app_key, aidata_scene, urlparse(file_path).netloc)
    bucket_name = oss_info["bucketName"]
    pos = file_path.find("://")
    if pos == -1:
        file_path = os.path.join(f"oss://{bucket_name}/", file_path)
    if not file_path.startswith(f"oss://{bucket_name}/"):
        raise ValueError(f"invalid oss path: {file_path}, it should start with oss://{bucket_name}/")

    path_key = file_path.replace(f"oss://{bucket_name}/", "")

    sleep_time = 10
    retries = 3
    while True:
        try:
            bucket = create_aidata_oss_bucket(oss_info)
            return {
                "bytes": bucket.get_object(path_key).read(),
                "path": file_path
            }
        except Exception as e:
            import oss2.exceptions
            if isinstance(e, (oss2.exceptions.AccessDenied, oss2.exceptions.ServerError)):
                try:
                    oss_info.update(fetch_aidata_oss_info(aidata_app_key, aidata_scene, urlparse(file_path).netloc))
                except Exception as e1:
                    logger.error("read aidata oss failed, path=%s, exception=%s, refresh oss info exception=%s",
                                 file_path, str(e), str(e1))
                    raise e from None
            retries -= 1
            if retries > 0:
                logger.warning("read aidata oss failed, %s retries left, path=%s, exception=%s", retries,
                               file_path, str(e))
                time.sleep(sleep_time)
            else:
                logger.error("read aidata oss failed, path=%s, exception=%s",
                             file_path, str(e))
                raise e

def load_oss_file(file_path, media_type, oss_access_key_id, oss_access_key_secret, oss_endpoint, oss_security_token=None,
                  ignore_not_exist=False, ignore_decode_fail=False, ignore_read_fail=False, print_ignore_log=True,
                  lazy_load=False):
    sleep_time = 10
    retries = 3

    if file_path.startswith("oss://"):
        if not oss_access_key_id:
            raise ValueError("missing 'oss_access_key_id' parameter in 'extras'")
        if not oss_access_key_secret:
            raise ValueError("missing 'oss_access_key_secret' parameter in 'extras'")
        if not oss_endpoint:
            raise ValueError("missing 'oss_endpoint' parameter in 'extras'")
        import oss2
        if oss_security_token:
            auth = oss2.StsAuth(oss_access_key_id, oss_access_key_secret, oss_security_token)
        else:
            auth = oss2.Auth(oss_access_key_id, oss_access_key_secret)

        path = file_path.replace("oss://", "")

        index = path.find('/')
        bucket_name = path[0:index]
        path_key = path[index + 1:]
        bucket = oss2.Bucket(auth, oss_endpoint, bucket_name)

        while True:
            try:
                data = {
                    "bytes": bucket.get_object(path_key).read(),
                    "path": file_path
                }
                break
            except Exception as e:
                if isinstance(e, (oss2.exceptions.NoSuchKey, oss2.exceptions.NoSuchBucket)):
                    if ignore_not_exist:
                        if print_ignore_log:
                            logger.warning("ignore path not exist, path=%s, exception=%s", file_path, repr(e))
                        return None
                    else:
                        logger.error("read oss failed, path=%s, exception=%s", file_path, repr(e))
                        raise e
                retries -= 1
                if retries > 0:
                    logger.warning("read oss failed, %s retries left, path=%s, exception=%s",
                                   retries, file_path, repr(e))
                    time.sleep(sleep_time)
                else:
                    if ignore_read_fail:
                        if print_ignore_log:
                            logger.warning("ignore read path fail, path=%s, exception=%s", file_path, repr(e))
                        return None
                    else:
                        logger.error("read oss failed, path=%s, exception=%s", file_path, repr(e))
                        raise e
    else:
        import requests
        session = requests.Session()

        while True:
            try:
                response = session.get(file_path)
                response.raise_for_status()
                data = {
                    "bytes": response.content,
                    "path": file_path
                }
                break
            except Exception as e:
                retries -= 1
                if retries > 0:
                    logger.warning("read url failed, %s retries left, url=%s, exception=%s",
                                   retries, file_path, str(e))
                    time.sleep(sleep_time)
                else:
                    logger.error("read url failed, url=%s, exception=%s", file_path, str(e))
                    raise e

    if ignore_decode_fail:
        try:
            decoded_data = decode_example(media_type, data)
            if lazy_load:
                return decoded_data
        except Exception as e:
            if print_ignore_log:
                logger.warning("ignore decode data fail, path=%s, exception=%s", file_path, repr(e))
            return None
    return data


def load_file(path):
    from urllib.parse import parse_qs
    pos = path.rfind('?')
    query = {} if pos < 0 else path[pos + 1:]
    params = {}
    if query:
        url_params = parse_qs(query)
        for key, value in url_params.items():
            if len(value) > 1:
                raise ValueError("multiple value is set for parameter: {}={}".format(key, value))
            if key in ("ignore_not_exist", "ignore_decode_fail", "ignore_read_fail", "print_ignore_log"):
                params[key] = str(value[0]).lower() == "true"
            else:
                params[key] = value[0]

    path = path if pos < 0 else path[:pos]
    if "aidata_app_key" in params:
        return load_aidata_oss_file(path, **params)
    else:
        return load_oss_file(path, lazy_load=True, **params)
