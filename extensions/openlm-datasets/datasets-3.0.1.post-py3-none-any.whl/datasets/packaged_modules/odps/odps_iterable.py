from copy import deepcopy
from itertools import islice
from typing import Callable, Tuple

import datasets
import numpy as np
import pyarrow as pa
from datasets import config
from datasets.formatting import PythonFormatter
from datasets.iterable_dataset import _BaseExamplesIterable, Key, _batch_to_examples
from datasets.utils.sharding import _split_gen_kwargs, _merge_gen_kwargs, _number_of_shards_in_gen_kwargs, \
    _shuffle_gen_kwargs

logger = datasets.utils.logging.get_logger(__name__)


def resume_shards(shards, shard_example_idx_start):
    shards_new = []
    for shard in shards:
        item_idx, shard_idx, start, stop, offset = shard
        if stop - start <= shard_example_idx_start:
            shard_example_idx_start -= stop - start
            shards_new.append((item_idx, shard_idx, start, stop, stop - start))
        else:
            if shard_example_idx_start > 0:
                shards_new.append((item_idx, shard_idx, start, stop, shard_example_idx_start))
                shard_example_idx_start = 0
            else:
                shards_new.append((item_idx, shard_idx, start, stop, 0))
    from .odps_util import get_process_name
    logger.warning("%s - resume shards, change from %s to %s", get_process_name(), shards, shards_new)
    return shards_new


class OdpsExamplesIterable(_BaseExamplesIterable):
    def __init__(self, generate_tables_fn: Callable[..., Tuple[Key, pa.Table]], kwargs: dict):
        super().__init__()
        self.generate_tables_fn = generate_tables_fn
        self.kwargs = kwargs

    @property
    def iter_arrow(self):
        return self._iter_arrow

    def _init_state_dict(self) -> dict:
        self._state_dict = {"shard_idx": 0, "shard_example_idx": 0}
        return self._state_dict

    def __iter__(self):
        formatter = PythonFormatter()
        shard_idx_start = self._state_dict["shard_idx"] if self._state_dict else 0
        for gen_kwags in islice(_split_gen_kwargs(self.kwargs, max_num_jobs=self.n_shards), shard_idx_start, None):
            shard_example_idx_start = self._state_dict["shard_example_idx"] if self._state_dict else 0
            if shard_example_idx_start > 0:
                gen_kwags["shards"] = resume_shards(gen_kwags["shards"], shard_example_idx_start)
            for key, pa_table in self.generate_tables_fn(**gen_kwags):
                for pa_subtable in pa_table.to_reader(max_chunksize=config.ARROW_READER_BATCH_SIZE_IN_DATASET_ITER):
                    formatted_batch = formatter.format_batch(pa_subtable)
                    for example in _batch_to_examples(formatted_batch):
                        if self._state_dict:
                            self._state_dict["shard_example_idx"] += 1
                        yield key, example
            if self._state_dict:
                self._state_dict["shard_idx"] += 1
                self._state_dict["shard_example_idx"] = 0

    def _iter_arrow(self):
        shard_idx_start = self._state_dict["shard_idx"] if self._state_dict else 0
        for gen_kwags in islice(_split_gen_kwargs(self.kwargs, max_num_jobs=self.n_shards), shard_idx_start, None):
            shard_example_idx_start = self._state_dict["shard_example_idx"] if self._state_dict else 0
            if shard_example_idx_start > 0:
                gen_kwags["shards"] = resume_shards(gen_kwags["shards"], shard_example_idx_start)
            for key, pa_table in self.generate_tables_fn(**gen_kwags):
                if self._state_dict:
                    self._state_dict["shard_example_idx"] += len(pa_table)
                yield key, pa_table
            if self._state_dict:
                self._state_dict["shard_idx"] += 1
                self._state_dict["shard_example_idx"] = 0

    def shuffle_data_sources(self, generator: np.random.Generator) -> "OdpsExamplesIterable":
        return ShuffledDataSourcesOdpsExamplesIterable(self.generate_tables_fn, self.kwargs, generator)

    def shard_data_sources(self, worker_id: int, num_workers: int) -> "OdpsExamplesIterable":
        """Keep only the requested shard."""
        gen_kwargs_list = _split_gen_kwargs(self.kwargs, max_num_jobs=self.n_shards)
        shard_indices = self.split_shard_indices_by_worker(worker_id, num_workers)
        requested_gen_kwargs = _merge_gen_kwargs([gen_kwargs_list[i] for i in shard_indices])
        return OdpsExamplesIterable(self.generate_tables_fn, requested_gen_kwargs)

    @property
    def n_shards(self) -> int:
        return _number_of_shards_in_gen_kwargs(self.kwargs)


class ShuffledDataSourcesOdpsExamplesIterable(OdpsExamplesIterable):
    def __init__(
            self,
            generate_tables_fn: Callable[..., Tuple[Key, pa.Table]],
            kwargs: dict,
            generator: np.random.Generator,
    ):
        super().__init__(generate_tables_fn, kwargs)
        self.generator = deepcopy(generator)

    def _init_state_dict(self) -> dict:
        self._state_dict = {"shard_idx": 0, "shard_example_idx": 0}
        return self._state_dict

    def __iter__(self):
        """Shuffle the kwargs order to shuffle shards"""
        rng = deepcopy(self.generator)
        kwargs_with_shuffled_shards = _shuffle_gen_kwargs(rng, self.kwargs)
        formatter = PythonFormatter()
        shard_idx_start = self._state_dict["shard_idx"] if self._state_dict else 0
        for gen_kwags in islice(
                _split_gen_kwargs(kwargs_with_shuffled_shards, max_num_jobs=self.n_shards), shard_idx_start, None
        ):
            shard_example_idx_start = self._state_dict["shard_example_idx"] if self._state_dict else 0
            if shard_example_idx_start > 0:
                gen_kwags["shards"] = resume_shards(gen_kwags["shards"], shard_example_idx_start)
            for key, pa_table in self.generate_tables_fn(**gen_kwags):
                for pa_subtable in pa_table.to_reader(max_chunksize=config.ARROW_READER_BATCH_SIZE_IN_DATASET_ITER):
                    formatted_batch = formatter.format_batch(pa_subtable)
                    for example in _batch_to_examples(formatted_batch):
                        if self._state_dict:
                            self._state_dict["shard_example_idx"] += 1
                        yield key, example
            if self._state_dict:
                self._state_dict["shard_idx"] += 1
                self._state_dict["shard_example_idx"] = 0

    def _iter_arrow(self):
        rng = deepcopy(self.generator)
        kwargs_with_shuffled_shards = _shuffle_gen_kwargs(rng, self.kwargs)
        shard_idx_start = self._state_dict["shard_idx"] if self._state_dict else 0
        for gen_kwags in islice(
                _split_gen_kwargs(kwargs_with_shuffled_shards, max_num_jobs=self.n_shards), shard_idx_start, None
        ):
            shard_example_idx_start = self._state_dict["shard_example_idx"] if self._state_dict else 0
            if shard_example_idx_start > 0:
                gen_kwags["shards"] = resume_shards(gen_kwags["shards"], shard_example_idx_start)
            for key, pa_table in self.generate_tables_fn(**gen_kwags):
                if self._state_dict:
                    self._state_dict["shard_example_idx"] += len(pa_table)
                yield key, pa_table
            if self._state_dict:
                self._state_dict["shard_idx"] += 1
                self._state_dict["shard_example_idx"] = 0

    def shard_data_sources(self, worker_id: int, num_workers: int) -> "OdpsExamplesIterable":
        """Keep only the requested shard."""
        rng = deepcopy(self.generator)
        kwargs_with_shuffled_shards = _shuffle_gen_kwargs(rng, self.kwargs)
        return OdpsExamplesIterable(self.generate_tables_fn, kwargs_with_shuffled_shards).shard_data_sources(
            worker_id, num_workers
        )
