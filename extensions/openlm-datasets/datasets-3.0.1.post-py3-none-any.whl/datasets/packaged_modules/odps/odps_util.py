# -*- coding: utf-8 -*-
import json
import os
import shutil
import time
import traceback
from pathlib import Path
from urllib.parse import urlencode

import odps
from odps import ODPS

from datasets.packaged_modules.odps.odps_items import OdpsItem
from odps.models import Schema
from odps.errors import NoPermission
from urllib3.exceptions import NewConnectionError

import datasets
from datasets.utils._filelock import FileLock
from datasets.utils.cypher_util import Cypher

logger = datasets.utils.logging.get_logger(__name__)

BUFFER_MAX_SIZE = 100
RETRY_MAX_TIME = 60 * 20
RETRY_SLEEP_TIME = 30


def create_odps(odps_project, access_id, access_key, end_point):
    if odps_project is None or len(odps_project) <= 0:
        raise ("odps_project is empty")

    if access_id is None or len(access_id) <= 0:
        raise RuntimeError("access_id is empty")

    if access_key is None or len(access_key) <= 0:
        raise RuntimeError("access_key is empty")

    if end_point is None or len(end_point) <= 0:
        raise RuntimeError("end_point is empty")

    logger.info("create odps, access_id=%s, access_key=%s, project=%s, end_point:%s", Cypher.hidden(access_id),
                Cypher.hidden(access_key), odps_project, end_point)
    return odps.ODPS(access_id, access_key, odps_project, end_point)


def create_download_session(odps_item: OdpsItem,
                            retry_max_time=RETRY_MAX_TIME,
                            retry_sleep_time=RETRY_SLEEP_TIME):
    _odps = create_odps(access_id=odps_item.access_id,
                        access_key=odps_item.access_key,
                        odps_project=odps_item.odps_project,
                        end_point=odps_item.end_point)

    from odps.tunnel import TableTunnel
    _table_tunnel = TableTunnel(odps=_odps, endpoint=odps_item.tunnel_end_point)

    retry_start_time = time.time()
    while True:
        try:
            _download_session = _table_tunnel.create_download_session(
                odps_item.odps_table, partition_spec=odps_item.odps_partitions)
            logger.info("create download session success after waiting for %s seconds", time.time() - retry_start_time)
            return _download_session
        except Exception as e:
            if (time.time() - retry_start_time) < retry_max_time \
                    and "MissingPartitionSpec" not in str(e) \
                    and "InvalidPartitionSpec" not in str(e) \
                    and "Invalid partition spec" not in str(e) \
                    and "NoSuchPartition" not in str(e) \
                    and not isinstance(e, (NoPermission,)):
                logger.warn("create download session failed, retry left time: %s seconds, error: %s | %s",
                            int(retry_max_time - (time.time() - retry_start_time)), e, traceback.format_exc())
                time.sleep(retry_sleep_time)
            else:
                logger.error("create download session failed after retry for %s seconds, give up",
                             int(time.time() - retry_start_time))
                raise e

# called by chief
def create_table(odps_project, odps_table, column_names, partition_names, lifecycle, access_id, access_key, access_project, end_point,
                 retry_max_time=RETRY_MAX_TIME,
                 retry_sleep_time=RETRY_SLEEP_TIME,
                 column_types=None):
    logger.info("create table, odps_project=%s, odps_table=%s, column_names=%s, partition_names=%s, lifecycle=%s, "
                "access_id=%s, access_key=%s, access_project=%s, end_point=%s, retry_max_time=%s, retry_sleep_time=%s, column_types=%s",
                odps_project, odps_table, column_names, partition_names, lifecycle,
                Cypher.hidden(access_id), Cypher.hidden(access_key), access_project, end_point, retry_max_time,
                retry_sleep_time, column_types)
    if odps_project is None or len(odps_project) <= 0:
        raise RuntimeError("odps_project is empty")

    if odps_table is None or len(odps_table) <= 0:
        raise RuntimeError("odps_table is empty")

    if column_names is None or len(column_names) <= 0:
        raise RuntimeError("column_names is empty")

    if partition_names is None or len(partition_names) <= 0:
        raise RuntimeError("partition_names is empty")

    if lifecycle <= 0:
        lifecycle = 1

    column_types = column_types or ["STRING" for column_name in column_names]
    partition_types = ["STRING" for partition_name in partition_names]
    table_schema = Schema.from_lists(column_names, column_types, partition_names, partition_types)

    retry_start_time = time.time()
    while True:
        try:
            _odps = create_odps(access_project or odps_project, access_id, access_key, end_point)
            if _odps.exist_table(odps_table):
                _table = _odps.get_table(odps_table)
                old_table_schema = _table.schema
                old_names = [column.name for column in old_table_schema.columns]
                old_types = [column.type for column in old_table_schema.columns]
                names = [column.name for column in table_schema.columns]
                types = [column.type for column in table_schema.columns]
                if names != old_names:
                    raise RuntimeError(
                        "table {} is exists, but column/partition names are different, expected={}, actually={}".format(
                            odps_table, str(names), str(old_names)))

                if types != old_types:
                    raise RuntimeError(
                        "table {} is exists, but column/partition types are different, expected={}, actually={}".format(
                            odps_table, str(types), str(old_types)))

                logger.info("create table success, table is already exist, odps_table=%s, table_schema=%s", odps_table,
                            str(table_schema))
            else:
                _table = _odps.create_table(odps_table, table_schema, if_not_exists=True, lifecycle=lifecycle)
                logger.info("create table success, odps_table=%s, table_schema=%s", odps_table,
                            str(table_schema))
            return _table
        except Exception as e:
            if isinstance(e, RuntimeError):
                raise e
            if (time.time() - retry_start_time) < retry_max_time:
                logger.warn("create table failed, retry left time: %s seconds, error: %s | %s",
                            int(retry_max_time - (time.time() - retry_start_time)), e, traceback.format_exc())
                time.sleep(retry_sleep_time)
            else:
                logger.error("create table failed after retry for %s seconds, give up",
                             int(time.time() - retry_start_time))
                raise e


# called by worker
def get_table(odps_project, odps_table, access_id, access_key, access_project, end_point,
              retry_max_time=RETRY_MAX_TIME,
              retry_sleep_time=RETRY_SLEEP_TIME,
              wait=True):
    retry_start_time = time.time()
    while True:
        try:
            _odps = create_odps(access_project or odps_project, access_id, access_key, end_point)
            _table = _odps.get_table(odps_table, project=odps_project)
            logger.info("get table success, odps_table=%s", odps_table)
            return _table
        except Exception as e:
            if isinstance(e, RuntimeError):
                raise e
            if (time.time() - retry_start_time) < retry_max_time:
                logger.warn("get table failed, retry left time: %s seconds, error: %s | %s",
                            int(retry_max_time - (time.time() - retry_start_time)), e, traceback.format_exc())
                time.sleep(retry_sleep_time)
            else:
                logger.error("get table failed after retry for %s seconds, give up",
                             int(time.time() - retry_start_time))
                raise e


def odps_type_to_feature_type(type):
    type = type.upper()
    if type == "STRING" or "VARCHAR" in type:
        return datasets.Value(dtype="string")
    elif type == "TINYINT":
        return datasets.Value(dtype="int8")
    elif type == "SMALLINT":
        return datasets.Value(dtype="int16")
    elif type == "INT":
        return datasets.Value(dtype="int32")
    elif type == "BIGINT":
        return datasets.Value(dtype="int64")
    elif type == "FLOAT":
        return datasets.Value(dtype="float32")
    elif type == "DOUBLE":
        return datasets.Value(dtype="float64")
    elif type == "DECIMAL":
        return datasets.Value(dtype="decimal128")
    elif type == "BINARY":
        return datasets.Value(dtype="binary")
    elif type == "DATETIME":
        return datasets.Value(dtype="date64")
    elif type == "TIMESTAMP":
        return datasets.Value(dtype="timestamp[ns]")
    elif type == "BOOLEAN":
        return datasets.Value(dtype="bool")
    elif type == "IMAGE":
        return datasets.Image()
    elif type == "IMAGE_LAZY":
        return datasets.Image(decode=False)
    elif type == "AUDIO":
        return datasets.Audio()
    elif type == "AUDIO_LAZY":
        return datasets.Audio(decode=False)
    elif type == "VIDEO":
        return datasets.Video()
    elif type == "VIDEO_LAZY":
        return datasets.Video(decode=False)
    elif type == "BINARY":
        return datasets.Binary()
    elif type == "BINARY_LAZY":
        return datasets.Binary(decode=False)
    elif type == "JSONOBJECT" or type == "JSON":
        return {}
    elif type == "JSONARRAY":
        return [datasets.Value(dtype="string")]
    elif "ARRAY" in type:
        array_count = type.count("ARRAY")
        sub_type = type.replace("ARRAY", "").replace("<", "").replace(">", "")
        feature = None
        if sub_type == "STRING" or "VARCHAR" in type:
            feature = datasets.Value(dtype="string")
        elif sub_type == "TINYINT":
            feature = datasets.Value(dtype="int8")
        elif sub_type == "SMALLINT":
            feature = datasets.Value(dtype="int16")
        elif sub_type == "INT":
            feature = datasets.Value(dtype="int32")
        elif sub_type == "BIGINT":
            feature = datasets.Value(dtype="int64")
        elif sub_type == "FLOAT":
            feature = datasets.Value(dtype="float32")
        elif sub_type == "DOUBLE":
            feature = datasets.Value(dtype="float64")
        elif sub_type == "":
            feature = datasets.Value(dtype="string")
        elif sub_type == "IMAGE":
            feature = datasets.Image()
        elif sub_type == "IMAGE_LAZY":
            feature = datasets.Image(decode=False)
        elif sub_type == "AUDIO":
            feature = datasets.Audio()
        elif sub_type == "AUDIO_LAZY":
            feature = datasets.Audio(decode=False)
        elif sub_type == "VIDEO":
            feature = datasets.Video()
        elif sub_type == "VIDEO_LAZY":
            feature = datasets.Video(decode=False)
        elif sub_type == "BINARY":
            feature = datasets.Binary()
        elif sub_type == "BINARY_LAZY":
            feature = datasets.Binary(decode=False)
        else:
            raise ValueError("unknown odps array sub type: {}".format(sub_type))

        for i in range(array_count):
            feature = [feature]
        return feature
    else:
        raise ValueError("unknown odps column type: {}".format(type))


def row_count_of_shards(shards):
    row_count = 0
    for start, stop in shards:
        row_count += stop - start
    return row_count


def shard_rows_naive(start: int, end: int, num_shards: int):
    row_count = end - start
    shards = []
    for shard_idx in range(num_shards):
        num_shards_to_add = row_count // num_shards + (shard_idx < (row_count % num_shards))
        if num_shards_to_add == 0:
            break
        shard_start = shards[-1][1] if shards else start
        shard = (shard_start, shard_start + num_shards_to_add)
        shards.append(shard)
    return shards


def shard_rows(table_path, row_count, start=None, end=None, num_workers=None, world_size=None, rank=None, drop_left=False, num_proc=None):
    params = {}
    if start is not None:
        if start < 0:
            raise ValueError("start must be greater than or equal to 0")
        if start >= row_count:
            raise ValueError(f"{table_path} contains {row_count} rows, but start is set as {start}")
        params["start"] = start
    else:
        start = 0

    if end is not None:
        if end <= 0:
            raise ValueError("end must be greater than 0")
        if end > row_count:
            raise ValueError(f"{table_path} contains {row_count} rows, but end is set as {end}")
        params["end"] = end
    else:
        end = row_count

    if params:
        table_path = f"{table_path}?{urlencode(params)}"
    row_count = end - start

    if world_size is not None:
        if num_proc is None:
            num_proc = num_workers
        if num_proc is None or num_proc <= 0:
            num_proc = 1
        num_shards = num_proc * world_size

        if row_count < world_size:
            raise ValueError(f"{table_path} contain {row_count} rows, which is less than num_shards={num_shards}")

        left_count = row_count % num_shards
        if left_count == 0:
            shards = shard_rows_naive(start=start, end=end, num_shards=num_shards)
            logger.warning(f"shard {table_path} of {row_count} rows across {world_size} nodes and {num_proc} "
                           f"workers, each shard contains {row_count // num_shards} rows, num_shards: {len(shards)}")
        elif drop_left:
            shards = shard_rows_naive(start=start, end=end - left_count, num_shards=num_shards)
            logger.warning(f"shard {table_path} of {row_count} rows across {world_size} nodes and {num_proc} "
                           f"workers, drop left {left_count} rows, each shard contains {row_count // num_shards} "
                           f"rows, num_shards: {len(shards)}")
        else:
            shards = shard_rows_naive(start=start, end=end, num_shards=num_shards)
            logger.warning(f"shard {table_path} of {row_count} rows across {world_size} nodes and {num_proc} "
                           f"workers, keep all rows, each shard contains {row_count // num_shards} or "
                           f"{row_count // num_shards + 1} rows, num_shards: {len(shards)}")

        if rank is not None:
            shards = shards[rank * num_proc: (rank + 1) * num_proc]
            logger.warning(f"current node is rank {rank}, num_shards: {len(shards)}, "
                           f"row_count: {row_count_of_shards(shards)}, shards: {shards}")
    else:
        if num_proc is None:
            num_proc = num_workers
        if num_proc is None or num_proc <= 0:
            num_proc = 1
        shards = shard_rows_naive(start=start, end=end, num_shards=num_proc)
        logger.warning(f"shard {table_path} of {row_count} rows into maximum {num_proc} shards, num_shards: {len(shards)}")

    return shards


def inference_value_type(column_value):
    if column_value is None:
        return None
    elif isinstance(column_value, (tuple, list, set)):
        value_type = None
        for value in column_value:
            if value is not None:
                value_type = inference_value_type(value)
                break
        return "ARRAY<{}>".format(value_type or "")
    elif isinstance(column_value, (str, bytes)):
        return "STRING"
    elif isinstance(column_value, int):
        return "BIGINT"
    elif isinstance(column_value, float):
        return "DOUBLE"
    else:
        return "STRING"


def skip_data_for_sharding(shards, skip_data_length):
    skip_data_length_per_shards = skip_data_length // len(shards)
    new_sharding = [(_shard[0] + skip_data_length_per_shards, _shard[1]) for _shard in shards ]
    return new_sharding


def _get_table_meta_by_direct(table_path, inference_array_column=True):
    from common_io.exception import OutOfRangeException
    from common_io.table import TableReader

    columns = {}
    row_count = 0
    retries = 0
    max_retries = 5
    retry_sleep_time = 3
    reader = TableReader(table_path)
    while True:
        try:
            columns = {column[0]: column[1].upper() for column in reader.get_schema()}
            row_count = reader.get_row_count()

            if inference_array_column:
                array_columns = {column_name: column_type for column_name, column_type in columns.items() if
                                 column_type in ("array", "ARRAY")}
                if len(array_columns) > 0:
                    data = reader.read(num_records=1, allow_smaller_final_batch=True)[0]
                    column_names = [column[0] for column in reader.get_schema()]
                    column_values = {column_name: column_value for column_name, column_value in zip(column_names, data)}
                    for column_name, column_type in array_columns.items():
                        infered_column_type = inference_value_type(column_values[column_name])
                        if infered_column_type is not None:
                            columns[column_name] = infered_column_type
                            logger.warning("table: %s, column: %s, type: %s, infered_type: %s",
                                           table_path, column_name, column_type, infered_column_type)
            break
        except Exception as e:
            retries += 1
            if retries < max_retries:
                import traceback
                logger.warning("get odps table meta failed, %s retries left, error: %s | %s",
                               max_retries - retries, e, traceback.format_exc())
                time.sleep(retry_sleep_time)
                continue
            else:
                raise e

    try:
        reader.close()
    except Exception as ce:
        import traceback
        logger.warning("get odps table meta close read failed, ignore, error: %s | %s",
                       ce, traceback.format_exc())
    return columns, row_count


def get_table_meta_by_direct_no_cache(table_path, inference_array_column=True):
    try:
        retries = 0
        max_retries = 3
        retry_sleep_time = 10
        while True:
            import concurrent.futures
            with concurrent.futures.ProcessPoolExecutor(1) as executor:
                future = executor.submit(_get_table_meta_by_direct, table_path, inference_array_column)
                concurrent.futures.wait([future])
                if future.exception() is None:
                    columns, row_count = future.result()
                    break
                else:
                    retries += 1
                    if retries < max_retries:
                        import traceback
                        logger.warning("get odps table meta failed, %s retries left, error: %s",
                                       max_retries - retries, repr(future.exception()))
                        time.sleep(retry_sleep_time)
                        continue
                    else:
                        raise IOError("get odps table meta failed")
    except AssertionError as e:
        if "daemonic processes are not allowed to have children" in str(e):
            columns, row_count = _get_table_meta_by_direct(table_path, inference_array_column)
        else:
            raise e

    return columns, row_count


def get_table_meta_by_direct(table_path, inference_array_column=True):
    odps_io_config_file = os.environ.get("ODPS_IO_CONFIG_FILE", "./odps_io_config")
    if os.path.exists(odps_io_config_file):
        import hashlib
        with open(odps_io_config_file, "rb") as fp:
            file_hash = hashlib.md5()
            while chunk := fp.read(100 * 1024 * 1024):
                file_hash.update(chunk)
        cache_file = os.path.join(os.path.dirname(odps_io_config_file), ".odps_meta_cache",
                                  f"{table_path.replace('odps://', '').replace('/', '_')}_{file_hash.hexdigest()}")

        Path(cache_file).parent.mkdir(parents=True, exist_ok=True)
        cache_lock_file = cache_file + ".lock"
        with FileLock(cache_lock_file):
            if not os.path.exists(cache_file):
                logger.info("get table meta at the first time")
                columns, row_count = get_table_meta_by_direct_no_cache(table_path, inference_array_column)
                cache_incomplete_file = cache_file + ".incomplete"

                if os.path.exists(cache_incomplete_file):
                    shutil.rmtree(cache_incomplete_file)
                with open(cache_incomplete_file, "w") as fp:
                    json.dump({"columns": columns, "row_count": row_count}, fp, indent=4)
                os.rename(cache_incomplete_file, cache_file)
                return columns, row_count
            else:
                logger.info("get table meta from cache file: %s", cache_file)
                with open(cache_file, "r") as fp:
                    data = json.load(fp)
                return data["columns"], data["row_count"]
    else:
        logger.info("get table meta without cache")
        columns, row_count = get_table_meta_by_direct_no_cache(table_path, inference_array_column)
        return columns, row_count


def get_table_meta_by_tunnel(odps_item: OdpsItem, return_row_count=True):
    table = get_table(odps_project=odps_item.odps_project,
                       odps_table=odps_item.odps_table,
                       access_id=odps_item.access_id,
                       access_key=odps_item.access_key,
                       access_project=odps_item.access_project,
                       end_point=odps_item.end_point,
                       wait=False)
    if table is None:
        raise RuntimeError("table isn't exists, odps_project={}, odps_table={}".format(odps_item.odps_project, odps_item.odps_table))

    columns = {}
    for column in table.schema._columns:
        columns[column.name] = str(column.type).upper()

    row_count = -1
    if return_row_count:
        table_reader = create_table_reader(table=table, partition=odps_item.odps_partitions)
        row_count = table_reader.count

    return columns, row_count


def get_table_meta_by_raw_tunnel(odps_item: OdpsItem, return_row_count=True):
    _download_session = create_download_session(odps_item=odps_item)
    _table_schema = _download_session.schema
    columns = {}
    for column in _table_schema.simple_columns:
        columns[column.name] = str(column.type).upper()
    row_count = -1
    if return_row_count:
        row_count = _download_session.count

    return columns, row_count


def merge_columns_with_special_column_types(columns, special_column_types, extras):
    pre_processors = {}
    if special_column_types is None:
        return columns, pre_processors

    if extras is None:
        extras = {}
    columns_new = {}
    for column_name, column_type in columns.items():
        if column_name in special_column_types:
            target_column_type = special_column_types[column_name]
            if target_column_type.upper() == "IMAGE":
                if column_type.upper() == "BINARY":
                    columns_new[column_name] = target_column_type
                elif column_type.upper() == "STRING":
                    from .odps_processors import DecodeBase64Processor
                    columns_new[column_name] = target_column_type
                    pre_processors[column_name] = DecodeBase64Processor(**extras)
                else:
                    raise ValueError(
                        f"can't transform {column_name} from {column_type} to {target_column_type}")
            elif target_column_type.upper() in ("JSONOBJECT", "JSONARRAY") or target_column_type.upper().startswith("ARRAY"):
                if column_type.upper() == "STRING":
                    from .odps_processors import DecodeJsonProcessor
                    columns_new[column_name] = target_column_type
                    pre_processors[column_name] = DecodeJsonProcessor(**extras)
                else:
                    raise ValueError(
                        f"can't transform {column_name} from {column_type} to {target_column_type}")
            elif target_column_type.upper() in ("REF_IMAGE", "REF_AUDIO", "REF_VIDEO", "REF_BINARY"):
                if column_type.upper() not in ("STRING", "ARRAY<STRING>"):
                    raise ValueError(
                        f"can't transform {column_name} from {column_type} to {target_column_type}")
                if column_type.upper() == "STRING" and "path_seperator" in extras and extras["path_seperator"]:
                    column_type = "ARRAY<STRING>"
                column_type_new = target_column_type.upper().replace("REF_", "")
                from .odps_processors import RefProcessor
                processor = RefProcessor(**extras, multiple="ARRAY" in column_type.upper(), media_type=column_type_new)
                if processor.is_lazy_load():
                    column_type_new += "_LAZY"
                columns_new[column_name] = column_type.upper().replace("STRING", column_type_new)
                pre_processors[column_name] = processor
            elif target_column_type.upper() in ("AIDATA_REF_IMAGE", "AIDATA_REF_AUDIO", "AIDATA_REF_VIDEO"):
                if column_type.upper() not in ("STRING", "ARRAY<STRING>"):
                    raise ValueError(
                        f"can't transform {column_name} from {column_type} to {target_column_type}")
                from .odps_processors import AiDataRefProcessor
                processor = AiDataRefProcessor(**extras, aidata_scene=target_column_type.upper().replace("AIDATA_REF_", ""),
                                               multiple="ARRAY" in column_type.upper())
                column_type_new = target_column_type.upper().replace("AIDATA_REF_", "")
                if processor.is_lazy_load():
                    column_type_new += "_LAZY"
                columns_new[column_name] = column_type.upper().replace("STRING", column_type_new)
                pre_processors[column_name] = processor
            else:
                raise ValueError(f"not supported special column type: {column_name}={target_column_type}")
        else:
            columns_new[column_name] = column_type

    for column_name, column_type in special_column_types.items():
        if column_name not in columns:
            raise ValueError(f"unknown column {column_name} in special_column_types: {special_column_types}, "
                            f"all columns: {list(columns.keys())}")
    return columns_new, pre_processors


def get_multimedia_types(features):
    if isinstance(features, dict):
        if "_type" in features and isinstance(features["_type"], str):
            if features["_type"] in ["Video", "Image", "Audio", "Binary"]:
                return {features["_type"]}
            else:
                return set()
        else:
            types = set()
            for key, value in features.items():
                types = types.union(get_multimedia_types(value))
            return types
    elif isinstance(features, (list, tuple)):
        types = set()
        for feature in features:
            types = types.union(get_multimedia_types(feature))
        return types
    else:
        return set()


def create_download_session_reader(download_session, start, count, columns=None,
                                   retry_max_time=RETRY_MAX_TIME,
                                   retry_sleep_time=RETRY_SLEEP_TIME):
    retry_start_time = time.time()
    while True:
        try:
            _reader = download_session.open_record_reader(start, count, columns=columns)
            logger.info("create download session reader success after waiting for %s seconds",
                        time.time() - retry_start_time)
            return _reader
        except Exception as e:
            if (time.time() - retry_start_time) < retry_max_time:
                logger.warn("create download session reader failed, retry left time: %s seconds, error: %s | %s",
                            int(retry_max_time - (time.time() - retry_start_time)), e, traceback.format_exc())
                time.sleep(retry_sleep_time)
            else:
                logger.error("create download session reader failed after retry for %s seconds, give up",
                             int(time.time() - retry_start_time))
                raise e

def create_table_reader(table, partition,
                        columns=None,
                        retry_max_time=RETRY_MAX_TIME,
                        retry_sleep_time=RETRY_SLEEP_TIME):
    if partition and '/' in partition:
        partition = partition.replace('/', ',')
    retry_start_time = time.time()
    while True:
        try:
            table_reader = table.open_reader(
                partition=partition,
                columns=columns,
                reopen=True)
            logger.info("create reader success after waiting for %s seconds", time.time() - retry_start_time)
            return table_reader
        except Exception as e:
            if (time.time() - retry_start_time) < retry_max_time \
                    and "MissingPartitionSpec" not in str(e) \
                    and "InvalidPartitionSpec" not in str(e) \
                    and "Invalid partition spec" not in str(e)\
                    and "NoSuchPartition" not in str(e)\
                    and not isinstance(e, (NoPermission,)):
                logger.warn("create reader failed, retry left time: %s seconds, error: %s | %s",
                            int(retry_max_time - (time.time() - retry_start_time)), e, traceback.format_exc())
                time.sleep(retry_sleep_time)
            else:
                logger.error("create reader failed after retry for %s seconds, give up",
                             int(time.time() - retry_start_time))
                raise e


def create_table_writer(table, partition_names, partition_values,
                        buffer_max_size=BUFFER_MAX_SIZE,
                        retry_max_time=RETRY_MAX_TIME,
                        retry_sleep_time=RETRY_SLEEP_TIME):
    partition = ",".join(["{}={}".format(name, value) for name, value in zip(partition_names, partition_values)])
    logger.info(
        'create table writer, odps_table=%s, partition=%s, buffer_max_size=%s, retry_max_time=%s, retry_sleep_time=%s',
        table.name, partition, buffer_max_size, retry_max_time, retry_sleep_time)
    table_writer = SyncOdpsTableWriter(table, partition, buffer_max_size, retry_max_time, retry_sleep_time)
    return table_writer


def delete_table_partition_if_exists(project_name, table_name, odps_table, partitions):
    if not odps_table.exist_partition(partitions):
        return
    logger.info("delete odps://%s/tables/%s/%s" % (project_name, table_name, partitions))
    odps_table.delete_partition(partitions, if_exists=True)


class SyncOdpsTableWriter(object):
    def __init__(self, table, partition,
                 buffer_max_size=BUFFER_MAX_SIZE,
                 retry_max_time=RETRY_MAX_TIME,
                 retry_sleep_time=RETRY_SLEEP_TIME):
        self._table = table
        self._partition = partition

        self._buffer_max_size = int(buffer_max_size)
        if self._buffer_max_size is None or self._buffer_max_size < 1:
            self._buffer_max_size = 1

        self._retry_max_time = int(retry_max_time)
        if self._retry_max_time is None or self._retry_max_time < 600:
            self._retry_max_time = 600

        self._retry_sleep_time = int(retry_sleep_time)
        if self._retry_sleep_time is None or self._retry_sleep_time < 10:
            self._retry_sleep_time = 10

        self._buffer = []
        self._table_writer = None
        self.create_writer()

    def create_writer(self, with_retry=True):
        retry_start_time = time.time()
        while True:
            try:
                self._table_writer = self._table.open_writer(
                    partition=self._partition,
                    blocks=None,
                    create_partition=True,
                    reopen=True)
                logger.info("create writer success after waiting for %s seconds", time.time() - retry_start_time)
                break
            except Exception as e:
                if with_retry and (time.time() - retry_start_time) < self._retry_max_time:
                    logger.warn("create writer failed, retry left time: %s seconds, error: %s | %s",
                                int(self._retry_max_time - (time.time() - retry_start_time)), e, traceback.format_exc())
                    time.sleep(self._retry_sleep_time)
                else:
                    logger.error("create writer failed after retry for %s seconds, give up",
                                 int(time.time() - retry_start_time))
                    raise e

    def close_writer(self, with_retry=True, force=False):
        retry_start_time = time.time()
        while True:
            try:
                if self._table_writer:
                    self._table_writer.close()
                    self._table_writer = None
                logger.info("close writer success after waiting for %s seconds", time.time() - retry_start_time)
                break
            except Exception as e:
                if with_retry and (time.time() - retry_start_time) < self._retry_max_time:
                    logger.warning("close writer failed, retry left time: %s seconds, error: %s | %s",
                                   int(self._retry_max_time - (time.time() - retry_start_time)), e,
                                   traceback.format_exc())
                    time.sleep(self._retry_sleep_time)
                else:
                    if force:
                        logger.error("close writer failed after retry for %s seconds, give up",
                                     int(time.time() - retry_start_time))

                    logger.error("close writer failed after retry for %s seconds, give up",
                                 int(time.time() - retry_start_time))
                    raise e

    def flush(self):
        logger.info("flush, buffer size is %s", len(self._buffer))
        self.close()
        self.create_writer()
        logger.info("flush success")

    def close(self):
        retry_start_time = time.time()
        while True:
            try:
                if self._table_writer is None and len(self._buffer) > 0:
                    logger.info("close, create table writer and rewrite from buffer")
                    self.create_writer(with_retry=False)

                    for item in self._buffer:
                        self._table_writer.write(item)

                    self.close_writer(with_retry=False)
                    logger.info("close success, buffer size is %s", len(self._buffer))
                else:
                    self.close_writer(with_retry=False)
                    logger.info("close success")
                self._buffer = []
                break
            except Exception as e:
                if (time.time() - retry_start_time) < self._retry_max_time:
                    logger.warning("close failed, retry left time: %s seconds, error: %s | %s",
                                   int(self._retry_max_time - (time.time() - retry_start_time)), e,
                                   traceback.format_exc())
                    time.sleep(self._retry_sleep_time)
                    self._table_writer = None
                else:
                    logger.error("close failed after retry for %s seconds, give up",
                                 int(time.time() - retry_start_time))
                    raise e

    def write(self, rows):
        self._buffer.append(rows)

        retry_count = 0
        retry_start_time = time.time()
        while True:
            try:
                self._table_writer.write(rows)
                break
            except Exception as e:
                if (time.time() - retry_start_time) < self._retry_max_time and not isinstance(e, (NewConnectionError,)):
                    logger.warning("write failed, retry left time: %s seconds, error: %s | %s",
                                   int(self._retry_max_time - (time.time() - retry_start_time)), e,
                                   traceback.format_exc())
                    time.sleep(min(max(float(self._retry_sleep_time), 2 ** retry_count), 300))
                else:
                    logger.warning("write failed, try to flush, error: %s | %s", e, traceback.format_exc())
                    self._table_writer = None  # rewrite from buffer in flush
                    self.flush()
                    logger.info("write failed, but flush success, ignore error")
                    return
                retry_count += 1
        if len(self._buffer) >= self._buffer_max_size:
            self.flush()

def get_odps_account(account_type, token=None):
    if account_type == "user":
        from datasets.utils.openlm_client import get_user_odps_account
        odps_account = get_user_odps_account(token=token)
        access_id = odps_account.get("accessId", None)
        access_key = odps_account.get("accessKey", None)
        end_point = odps_account.get("endPoint", None)
    elif account_type == "platform":
        from datasets.utils.openlm_client import get_platform_odps_account
        odps_account = get_platform_odps_account(token=token)
        access_id = odps_account.get("access_id", None)
        access_key = odps_account.get("access_key", None)
        end_point = odps_account.get("end_point", None)
    else:
        raise ValueError("invalid account_type: {}, should be user or platform".format(account_type))

    from datasets.utils.cypher_util import Cypher
    if access_id:
        access_id = Cypher.decrypt(access_id)
    if access_key:
        access_key = Cypher.decrypt(access_key)

    return access_id, access_key, end_point


def get_process_name():
    import sys
    rank = None
    try:
        import torch.distributed
        rank = "rank_" + str(torch.distributed.get_rank())
    except:
        pass

    worker = "main"
    if "torch" in sys.modules:
        import torch.utils.data

        worker_info = torch.utils.data.get_worker_info()
        if worker_info is not None:
            worker = "worker_" + str(worker_info.id)
    return rank + "_" + worker if rank else worker
