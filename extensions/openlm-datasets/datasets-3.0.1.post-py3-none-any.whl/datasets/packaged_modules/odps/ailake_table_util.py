import time

from attr import dataclass
from datasets.packaged_modules.odps.odps_util import get_process_name
from datasets.utils.multimedia_util import decode_example

from datasets.utils.logging import get_logger

logger = get_logger(__name__)

LOOKUP_TABLE_READER_CACHE = {}


@dataclass
class LookupTableReadMetric:
    log_metric_interval: int = 10000
    _last_log_num: int = 0

    num: int = 0
    not_exist_num: int = 0
    decode_fail_num: int = 0
    read_fail_num: int = 0
    read_time: int = 0
    start_ts: float = time.time()

    def log_metric(self):
        cur_ts = time.time()
        logger.warning(
            "%s - read lookup table metric, num: %s, not_exist_num: %s, decode_fail_num: %s, read_fail_num: %s, rt: %sms, avg speed: %s",
            get_process_name(), self.num, self.not_exist_num, self.decode_fail_num, self.read_fail_num,
            int(self.read_time * 1000 / self.num) if self.num > 0 else 0,
            int(self.num / (cur_ts - self.start_ts)) if cur_ts - self.start_ts > 0 else 0)

    def add_num(self, read_time):
        self.num += 1
        self.read_time += read_time
        if self.num - self._last_log_num >= self.log_metric_interval:
            self._last_log_num = self.num
            self.log_metric()


    def add_not_exist_num(self):
        self.not_exist_num += 1

    def add_decode_fail_num(self):
        self.decode_fail_num += 1

    def add_read_fail_num(self):
        self.read_fail_num += 1


def create_lookup_table_reader(ailake_admin_address, log_metric_interval=10000):
    from lake.lookup_table import LookupTableReader
    reader = LookupTableReader()
    reader.open(ailake_admin_address)
    return [reader, LookupTableReadMetric(log_metric_interval=log_metric_interval)]


def get_lookup_table_reader(admin_address):
    global LOOKUP_TABLE_READER_CACHE
    if admin_address in LOOKUP_TABLE_READER_CACHE:
        return LOOKUP_TABLE_READER_CACHE[admin_address]
    else:
        return [None, None]


def get_or_create_lookup_table_reader(ailake_admin_address, log_metric_interval=10000):
    global LOOKUP_TABLE_READER_CACHE
    if ailake_admin_address in LOOKUP_TABLE_READER_CACHE:
        return LOOKUP_TABLE_READER_CACHE[ailake_admin_address]
    else:
        reader = create_lookup_table_reader(ailake_admin_address, log_metric_interval=log_metric_interval)
        LOOKUP_TABLE_READER_CACHE[ailake_admin_address] = reader
        return reader


def close_lookup_table_reader(admin_address):
    global LOOKUP_TABLE_READER_CACHE

    if admin_address in LOOKUP_TABLE_READER_CACHE:
        reader, metric = LOOKUP_TABLE_READER_CACHE.pop(admin_address)
        if reader is not None:
            metric.log_metric()
            reader.close()


def read_lookup_table(key, media_type, ailake_admin_address, log_metric_interval=10000,
                      ignore_not_exist=False, ignore_decode_fail=False,
                      ignore_read_fail=False, print_ignore_log=True, lazy_load=False):
    reader, metric = get_or_create_lookup_table_reader(ailake_admin_address, log_metric_interval=log_metric_interval)
    read_begin_ts = time.time()
    try:
        values = reader.batch_get_binary([key])
    except Exception as e:
        if ignore_read_fail:
            metric.add_read_fail_num()
            if print_ignore_log:
                logger.warning("ignore read table fail, key=%s, exception=%s", key, repr(e))
            return None
        else:
            logger.error("read table failed, key=%s, exception=%s", key, repr(e))
            raise e
    metric.add_num(time.time() - read_begin_ts)

    value = values[0]
    if value is None:
        if ignore_not_exist:
            metric.add_not_exist_num()
            if print_ignore_log:
                logger.warning("ignore key not exist, key=%s", key)
            return None
        else:
            raise IOError(f"read table failed, key not exists, key={key}")
    data = {
        "bytes": value,
        "path": key
    }
    if ignore_decode_fail:
        try:
            decoded_data = decode_example(media_type, data)
            if lazy_load:
                return decoded_data
        except Exception as e:
            metric.add_decode_fail_num()
            if print_ignore_log:
                logger.warning("ignore decode data fail, key=%s, exception=%s", key, repr(e))
            return None
    return data


def load_file_from_lookup_table(path):
    from urllib.parse import parse_qs
    pos = path.rfind('?')
    query = {} if pos < 0 else path[pos + 1:]
    params = {}
    if query:
        url_params = parse_qs(query)
        for key, value in url_params.items():
            if len(value) > 1:
                raise ValueError("multiple value is set for parameter: {}={}".format(key, value))
            if key in ("ignore_not_exist", "ignore_decode_fail", "ignore_read_fail", "print_ignore_log"):
                params[key] = str(value[0]).lower() == "true"
            elif key in ("log_metric_interval",):
                params[key] = int(value[0])
            else:
                params[key] = value[0]

    path = path if pos < 0 else path[:pos]
    if path.startswith("ailake://"):
        path = path[9:]

    return read_lookup_table(path, lazy_load=True, **params)
