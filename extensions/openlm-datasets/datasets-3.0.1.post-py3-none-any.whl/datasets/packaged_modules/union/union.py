from dataclasses import dataclass
from typing import Optional

import datasets
import datasets.config
import pyarrow as pa
from datasets.features.features import require_storage_cast, _check_if_features_can_be_aligned
from datasets.table import table_cast

from .union_items import UnionItem, UnionItemList, UnionItemDict

logger = datasets.utils.logging.get_logger(__name__)


@dataclass
class UnionConfig(datasets.BuilderConfig):
    """BuilderConfig for Odps."""
    union_item_dict: UnionItemDict = None
    seed: int = None
    features: Optional[datasets.Features] = None

    def __post_init__(self):
        self.union_item_dict = UnionItemDict()
        features_list = []
        for split_name, split_data_files in self.data_files.items():
            if isinstance(split_data_files, str):
                split_data_files = [split_data_files]
            if len(split_data_files) <= 0:
                continue

            split_union_item_list: UnionItemList = UnionItemList()
            split_features_list = []
            for split_data_file in split_data_files:
                union_item = UnionItem.parse(split_data_file)
                logger.warning("split: %s, data_file: %s, union_item: %s", split_name, split_data_file,
                               union_item.format())

                try:
                    split_features = datasets.get_dataset_config_info(union_item.dataset_name,
                                                                      config_name=union_item.config_name).features
                except Exception as e:
                    split_features = None
                    logger.warning("get dataset config info failed, error=%s", repr(e))

                if split_features is None:
                    from datasets.load import load_dataset_and_builder
                    _, builder_instance = load_dataset_and_builder(union_item.dataset_name,
                                                                   name=union_item.config_name)
                    split_features = builder_instance.info.features
                if union_item.fields:
                    split_features = datasets.Features(
                        {field: split_features[field] for field in union_item.fields})
                if union_item.field_mappings and len(union_item.field_mappings) > 0:
                    for field_old, field_new in union_item.field_mappings.items():
                        if field_old not in split_features:
                            raise Exception(
                                f"field {field_old} isn't found, all fields: {list(split_features.keys())}, union_item: {union_item.format()}")
                        if field_old == field_new:
                            continue
                        feature = split_features.pop(field_old)
                        split_features[field_new] = feature

                split_features_list.append(split_features)
                split_union_item_list.append(union_item)

            logger.warning("check if features can be aligned in split %s", split_name)
            _check_if_features_can_be_aligned(split_features_list)

            features_list.append(split_features_list[0])
            self.union_item_dict[split_name] = split_union_item_list

        logger.warning("check if features can be aligned between splits")
        _check_if_features_can_be_aligned(features_list)

        if self.seed is None:
            raise Exception("seed isn't set")
        self.seed = int(self.seed)
        logger.warning("union_items: %s, seed: %s", self.union_item_dict.format(), self.seed)
        self.features = features_list[0]

    def create_config_id(
            self,
            config_kwargs: dict,
            custom_features: Optional[datasets.Features] = None,
    ) -> str:
        config_kwargs = config_kwargs.copy()
        # We need to stringify the Selectable object to make its hash deterministic
        if "data_files" in config_kwargs:
            config_kwargs.pop("data_files")
        config_kwargs["union_items"] = self.union_item_dict
        return super().create_config_id(config_kwargs, custom_features=custom_features)


class Union(datasets.ArrowBasedBuilder):
    BUILDER_CONFIG_CLASS = UnionConfig

    def _info(self):
        return datasets.DatasetInfo(features=self.config.features)

    def _split_generators(self, dl_manager):
        splits = []
        for split_name, split_union_item_list in self.config.union_item_dict.items():
            splits.append(datasets.SplitGenerator(name=split_name, gen_kwargs={
                "split_name": split_name,
                "split_union_item_list": split_union_item_list,
                "seed": self.config.seed
            }))
        return splits

    def _cast_table(self, pa_table: pa.Table) -> pa.Table:
        if self.config.features is not None:
            schema = self.config.features.arrow_schema
            if all(not require_storage_cast(feature) for feature in self.config.features.values()):
                # cheaper cast
                pa_table = pa.Table.from_arrays([pa_table[field.name] for field in schema], schema=schema)
            else:
                # more expensive cast; allows str <-> int/float or str to Audio for example
                pa_table = table_cast(pa_table, schema)
        return pa_table

    def _generate_tables(self, split_name, split_union_item_list: UnionItemList, seed):
        dataset_list = []
        for union_item in split_union_item_list:
            dataset: datasets.Dataset = datasets.load_dataset(union_item.dataset_name,
                                                              name=union_item.config_name,
                                                              split=union_item.split_name)
            if union_item.fields:
                dataset = dataset.select_columns(union_item.fields)
            if union_item.field_mappings and len(union_item.field_mappings) > 0:
                dataset = dataset.rename_columns(union_item.field_mappings)
            dataset = dataset.shuffle(seed=seed)

            max_sample_count = union_item.max_sample_count
            if union_item.sample_ratio is not None:
                count = int(union_item.sample_ratio * len(dataset))
                if max_sample_count is None:
                    max_sample_count = count
                else:
                    max_sample_count = min(count, max_sample_count)

            if max_sample_count is not None:
                max_sample_count = min(len(dataset), max_sample_count)
                dataset = dataset.select(range(max_sample_count))

            dataset_list.append(dataset)

        lens = [len(dataset) for dataset in dataset_list]

        union_dataset = datasets.concatenate_datasets(dataset_list).shuffle(seed=seed)
        _row_count = len(union_dataset)
        logger.warning("split: %s, union dataset len: %s, sub datasets: %s, sub lens: %s, seed: %d",
                       split_name, _row_count, UnionItemList(split_union_item_list).format(), lens, seed)

        log_interval = max(1, int(_row_count / 10))
        for row_idx, data in enumerate(union_dataset):
            if (row_idx + 1) % log_interval == 0:
                logger.warning("split: %s, rows: %s/%s, progress: %.1f%%",
                               split_name, row_idx + 1, _row_count, 100 * (row_idx + 1) / _row_count)
            pa_table = pa.Table.from_pylist([data])
            yield row_idx, self._cast_table(pa_table)
