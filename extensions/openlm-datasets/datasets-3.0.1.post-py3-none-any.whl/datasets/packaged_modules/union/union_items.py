from typing import List, Dict


class UnionItem:
    dataset_name: str = None
    config_name: str = None
    split_name: str = None
    sample_ratio: float = None
    max_sample_count: int = None
    fields: List[str] = None
    field_mappings: Dict[str, str] = None

    @staticmethod
    def parse(param):
        union_item = UnionItem()

        if isinstance(param, dict):
            union_item.dataset_name = param.get("dataset_name", None)
            union_item.config_name = param.get("config_name", None)
            union_item.split_name = param.get("split_name", None)
            union_item.sample_ratio = float(param["sample_ratio"]) if "sample_ratio" in param else None
            union_item.max_sample_count = int(param["max_sample_count"]) if "max_sample_count" in param else None

            fields = param.get("fields", None)
            if fields is not None:
                if isinstance(fields, str):
                    union_item.fields = [field.strip() for field in fields.split(",") if
                                         len(field.strip()) > 0]
                elif isinstance(fields, (list, tuple)):
                    union_item.fields = [field.strip() for field in fields if len(field.strip()) > 0]
                else:
                    raise Exception(f"not supported type={type(fields)} of fields={fields}")

            field_mappings = param.get("field_mappings", None)
            if field_mappings is not None:
                if isinstance(field_mappings, str) and len(field_mappings.strip()) > 0:
                    mapping = {}
                    for kv in field_mappings.strip().split(','):
                        tmp = kv.split(':')
                        if len(tmp) != 2:
                            raise Exception(f"invalid field_mappings={field_mappings}")
                        mapping[tmp[0].strip()] = tmp[1].strip()
                    union_item.field_mappings = mapping
                elif isinstance(field_mappings, dict):
                    union_item.field_mappings = field_mappings
                else:
                    raise Exception(f"not supported type={type(field_mappings)} of field_mappings={field_mappings}")
        elif isinstance(param, str):
            from urllib.parse import parse_qs, urlparse
            parsed_url = urlparse(param)
            url_params = parse_qs(parsed_url.query)

            union_item = UnionItem()
            pos = param.find('?')
            prefix = param if pos < 0 else param[:pos]
            union_item.dataset_name = prefix.replace("union://", "")

            for key, value in url_params.items():
                if len(value) > 1:
                    raise Exception("multiple value is set for parameter: {}={}".format(key, value))
                value = value[0]
                if value is None:
                    continue
                if key == "config_name":
                    union_item.config_name = value
                elif key == "split_name":
                    union_item.split_name = value
                elif key == "sample_ratio":
                    union_item.sample_ratio = float(value)
                elif key == "max_sample_count":
                    union_item.max_sample_count = int(value)
                elif key == "fields":
                    union_item.fields = [field.strip() for field in value.split(",") if
                                         len(field.strip()) > 0]
                elif key == "field_mappings":
                    mapping = {}
                    for kv in value.strip().split(','):
                        tmp = kv.split(':')
                        if len(tmp) != 2:
                            raise Exception(f"invalid field_mappings={value}")
                        mapping[tmp[0].strip()] = tmp[1].strip()
                    union_item.field_mappings = mapping
                else:
                    raise Exception("unknown parameter name: {}".format(key))
        else:
            raise Exception(f"parse union item failed, unknown type {type(param)}, conf={param}")

        if union_item.sample_ratio is not None and union_item.sample_ratio > 1:
            raise Exception(f"sample_ratio is {union_item.sample_ratio}, it should be no more than 1")
        if union_item.max_sample_count is not None and union_item.max_sample_count < 0:
            raise Exception(f"max_sample_count is {union_item.max_sample_count}, it should be no less than 0")
        return union_item

    def format(self):
        params = {
            "config_name": self.config_name,
            "split_name": self.split_name,
            "sample_ratio": self.sample_ratio,
            "max_sample_count": self.max_sample_count
        }
        if self.fields is not None:
            params["fields"] = ",".join(self.fields)
        if self.field_mappings is not None:
            params["field_mappings"] = ",".join([f"{key}:{value}" for key, value in self.field_mappings.items()])

        return f"union://{self.dataset_name}?" \
               + "&".join([f"{key}={value}" for key, value in params.items() if value is not None])


class UnionItemList(List[UnionItem]):

    @staticmethod
    def parse(param_list):
        union_item_list: UnionItemList = UnionItemList()
        for param in param_list:
            union_item = UnionItem.parse(param)
            union_item_list.append(union_item)
        return union_item_list

    def format(self):
        return [item.format() for item in self]


class UnionItemDict(Dict[str, UnionItemList]):
    @staticmethod
    def parse(param_dict):
        union_item_dict: UnionItemDict = UnionItemDict()
        for split_name, split_param_list in param_dict.items():
            union_item_dict[split_name] = UnionItemList.parse(split_param_list)
        return union_item_dict

    def format(self):
        return {split_name: item_list.format() for split_name, item_list in self.items()}
