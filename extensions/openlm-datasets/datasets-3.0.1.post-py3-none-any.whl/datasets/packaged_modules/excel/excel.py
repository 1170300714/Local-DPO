import itertools
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Union, Sequence, Iterable, Hashable

import pandas as pd
import pyarrow as pa

import datasets
import datasets.config
from datasets.features.features import require_storage_cast
from datasets.table import table_cast
from datasets.utils.py_utils import Literal

logger = datasets.utils.logging.get_logger(__name__)


@dataclass
class ExcelConfig(datasets.BuilderConfig):
    """BuilderConfig for Excel."""

    features: Optional[datasets.Features] = None
    sheet_name: Optional[Union[str, int, List[int], List[str]]] = 0
    header: Optional[Union[int, Sequence[int]]] = 0
    names: Optional[List[str]] = None
    index_col: Optional[Union[int, Sequence[int]]] = None
    usecols: Optional[Union[int, str, Sequence[int], Sequence[str], Callable[[str], bool]]] = None
    engine: Optional[Literal["xlrd", "openpyxl", "odf", "pyxlsb"]] = None
    converters: Optional[Union[Dict[str, Callable], Dict[int, Callable]]] = None
    true_values: Optional[Iterable[Hashable]] = None
    false_values: Optional[Iterable[Hashable]] = None
    skiprows: Optional[Union[Sequence[int], int, Callable[[int], object]]] = None
    nrows: Optional[int] = None
    na_values = None
    keep_default_na: bool = True
    na_filter: bool = True
    verbose: bool = False
    parse_dates: Union[list, dict, bool] = False
    date_format: Optional[Union[Dict[Hashable, str], str]] = None
    thousands: Optional[str] = None
    decimal: str = "."
    skipfooter: int = 0

    def __post_init__(self):
        pass

    def default_engine(self):
        formats = set()
        for data_files in self.data_files.values():
            for data_file in data_files:
                formats.add(data_file.split('.')[-1])
        if len(formats) > 1:
            raise Exception(f"more than one format: {formats}")
        formats = list(formats)
        if formats[0] == "xls":
            return "xlrd"
        return "openpyxl"

    @property
    def pd_read_excel_kwargs(self):
        pd_read_excel_kwargs = {
            "sheet_name": self.sheet_name,
            "header": self.header,
            "names": self.names,
            "index_col": self.index_col,
            "usecols": self.usecols,
            "engine": self.engine or self.default_engine(),
            "converters": self.converters,
            "true_values": self.true_values,
            "false_values": self.false_values,
            "skiprows": self.skiprows,
            "nrows": self.nrows,
            "na_values": self.na_values,
            "keep_default_na": self.keep_default_na,
            "na_filter": self.na_filter,
            "verbose": self.verbose,
            "parse_dates": self.parse_dates,
            "date_format": self.date_format,
            "thousands": self.thousands,
            "decimal": self.decimal,
            "skipfooter": self.skipfooter
        }

        return pd_read_excel_kwargs


class Excel(datasets.ArrowBasedBuilder):
    BUILDER_CONFIG_CLASS = ExcelConfig

    def _info(self):
        return datasets.DatasetInfo(features=self.config.features)

    def _split_generators(self, dl_manager):
        """We handle string, list and dicts in datafiles"""
        if not self.config.data_files:
            raise ValueError(f"At least one data file must be specified, but got data_files={self.config.data_files}")
        data_files = dl_manager.download(self.config.data_files)
        if isinstance(data_files, (str, list, tuple)):
            files = data_files
            if isinstance(files, str):
                files = [files]
            files = [dl_manager.iter_files(file) for file in files]
            return [datasets.SplitGenerator(name=datasets.Split.TRAIN, gen_kwargs={"files": files})]
        splits = []
        for split_name, files in data_files.items():
            if isinstance(files, str):
                files = [files]
            files = [dl_manager.iter_files(file) for file in files]
            splits.append(datasets.SplitGenerator(name=split_name, gen_kwargs={"files": files}))
        return splits

    def _cast_table(self, pa_table: pa.Table) -> pa.Table:
        if self.config.features is not None:
            schema = self.config.features.arrow_schema
            if all(not require_storage_cast(feature) for feature in self.config.features.values()):
                # cheaper cast
                pa_table = pa.Table.from_arrays([pa_table[field.name] for field in schema], schema=schema)
            else:
                # more expensive cast; allows str <-> int/float or str to Audio for example
                pa_table = table_cast(pa_table, schema)
        return pa_table

    def _generate_tables(self, files):
        schema = self.config.features.arrow_schema if self.config.features else None
        # dtype allows reading an int column as str
        dtype = (
            {
                name: dtype.to_pandas_dtype() if not require_storage_cast(feature) else object
                for name, dtype, feature in zip(schema.names, schema.types, self.config.features.values())
            }
            if schema is not None
            else None
        )
        for i, file in enumerate(itertools.chain.from_iterable(files)):
            pa_table = pa.Table.from_pandas(pd.read_excel(file, dtype=dtype, **self.config.pd_read_excel_kwargs))
            yield i, self._cast_table(pa_table)
